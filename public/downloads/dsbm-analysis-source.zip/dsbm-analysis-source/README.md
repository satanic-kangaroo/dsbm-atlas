# DSBM Atlas: analysis source

The statistics behind DSBM Atlas, as plain Python (pandas, numpy, scipy, matplotlib). What each step does and why is
written on the site's Method page; this folder is the code and the aggregated results behind it.

```
01_scripts/common.py        paths, country-name canonicalisation, population table, genre rules, years-active parser, fixed periods
01_scripts/stats_utils.py   OLS (HC3), Poisson (robust SE), Kaplan-Meier, log-rank: numpy + scipy only
01_scripts/analysis/        analyze_01 .. analyze_07, build_regression_dataset.py, build_climate_dataset.py, build_economic_dataset.py, generate_summary.py
01_scripts/tests/           validate_data.py (integrity checks; writes 04_results/data_validation.json)
02_data/raw, processed      only the country-level inputs that come from public sources (see INPUT_SCHEMA.md)
03_figures/  04_results/    every figure and table the site is based on (aggregated: country, period, weekday)
RESULTS_SUMMARY.md          numbers generated from 04_results (Persian)         REPORT_fa.md = interpretation and limits (Persian)
```

## Run
`pip install -r requirements.txt && bash run_all.sh`. The band, release and album tables are not shipped (see
`INPUT_SCHEMA.md`); put your own tables with those columns in `02_data/raw/` and every number is recomputed.
With the original tables, the run reproduces the published results exactly (checked: robustness grid, theme tests,
survival table, release formats, month and weekday tests are byte-identical).

## Licence and data
Code: use it freely, credit DSBM Atlas. The band and release data belong to Metal Archives and its contributors.
Temperature: Berkeley Earth. GDP per person and internet use: World Bank.
