# Input tables (not included)

The band-level and release-level tables are a copy of data from Metal Archives and are **not part of this package**
(they belong to Metal Archives and its contributors). The scripts expect the following files in `02_data/raw/`.
Only the columns listed are read.

| File | Columns used by the analysis |
|---|---|
| `dsbm_enriched.csv` (one row per band) | `ma_id`, `name`, `country`, `country_detail`, `formed_in`, `genres_detail`, `status`, `years_active`, `themes`, `current_label`, `label_type`, `location`, `parse_version` |
| `dsbm_discography.csv` (one row per release listing) | `ma_id`, `album`, `type`, `year_raw`, `year`, `month`, `album_id`, `album_url` |
| `dsbm_album_details.csv` (one row per album) | `album_id`, `page_type`, `release_date_raw`, `year`, `month`, `day`, `date_precision` |

Country-level inputs that ARE included (derived from public sources): `climate_country.csv` (Berkeley Earth),
`worldbank_cache.csv` (World Bank), `temp_flags.csv`, `temp_overrides.csv` and the finished `regression_dataset.csv`.

Everything under `04_results/` and `03_figures/` is aggregated output (country, period or weekday level) produced by
`bash run_all.sh`; with your own tables in the same format the whole analysis re-runs unchanged.
