# خلاصه‌ی نتایج پروژه DSBM (تولید خودکار)

> همه‌ی اعداد از فایل‌های `04_results/` خوانده می‌شوند و در این اسکریپت دوباره محاسبه نمی‌شوند. تفسیر و محدودیت‌ها در `REPORT_fa.md` است.

## ⚠️ هشدارهای کیفیت داده

- ℹ️ 5 release rows (0.04%) have no album_id - negligible

## ۱. اطلاعات پایه

- تعداد بندها: **2186**
- بدون سال تأسیس: 590 (27.0%)
- بدون مضمون: 735 (33.6%)
- بندهای «International/Unknown» (بدون کشور): 102
- خلوص ژانر: 62.4% فقط DSBM
- وضعیت (٪ از کل): active 72.3%، split-up 15.8%، unknown 7.2%، changed name 2.9%، on hold 1.7%، disputed 0.0%
- میانه‌ی سن بندهای فعال: 7.0 سال (سال مرجع 2026)

### ۱۰ کشور برتر (خام)

| country | bands |
|---|---|
| United States | 415 |
| Russia | 219 |
| Germany | 128 |
| Brazil | 115 |
| Italy | 81 |
| United Kingdom | 81 |
| France | 79 |
| Mexico | 78 |
| Canada | 68 |
| Sweden | 58 |

### سرانه (حداقل 5 بند)

| country | bands | per_million |
|---|---|---|
| Finland | 39 | 7.09 |
| Sweden | 58 | 5.52 |
| Moldova | 7 | 2.69 |
| Lithuania | 7 | 2.41 |
| Norway | 12 | 2.18 |
| Georgia | 8 | 2.16 |
| Australia | 47 | 1.77 |
| Czechia | 19 | 1.74 |
| Netherlands | 31 | 1.73 |
| Canada | 68 | 1.7 |

### سال‌های اوج تأسیس

| year | bands |
|---|---|
| 2023 | 125 |
| 2024 | 123 |
| 2013 | 95 |

### بدون لیبل

| group | unsigned | bands | pct |
|---|---|---|---|
| بندهای فعال (لیبل فعلی) | 1099 | 1580 | 69.6 |
| بندهای غیرفعال (آخرین لیبل) | 340 | 606 | 56.1 |
| همه | 1439 | 2186 | 65.8 |

- مضامین صریحاً اقلیمی: 2.1% از بندهای دارای مضمون؛ طبیعت 9.0%؛ گرم 0.0%؛ روان‌شناختی 85.7%

## ۲. آزمون فرضیه‌ی اقلیمی

### رابطه‌ی ساده (OLS، خطای HC3)

| spec | n | pearson_r | spearman_rho | slope | p_HC3 | R2 |
|---|---|---|---|---|---|---|
| all_with_temp | 90 | -0.542 | -0.644 | -0.0852 | <0.001 | 0.294 |
| excl_bad_temp | 90 | -0.542 | -0.644 | -0.0852 | <0.001 | 0.294 |
| excl_bad_temp_min10 | 32 | -0.455 | -0.548 | -0.0861 | 0.031 | 0.207 |

### مدل شمارشی ساده (پواسون با offset جمعیت)

| spec | n | pct_change_per_C | p_robust | dispersion |
|---|---|---|---|---|
| poisson_excl_bad_temp | 90 | -7.9 | 0.001 | 48.0 |
| poisson_excl_bad_temp_min10 | 32 | -2.9 | 0.313 | 89.6 |

### جدول حساسیت (رگرسیون با کنترل GDP و اینترنت)

| spec | model | n | temp_coef | temp_p | internet_p | gdp_p | R2 |
|---|---|---|---|---|---|---|---|
| S0 legacy count: bands with year only | OLS | 89 | -0.0452 | <0.001 | 0.955 | 0.103 | 0.32 |
| S1 all bands counted (no exclusions) | OLS | 89 | -0.0683 | <0.001 | 0.862 | 0.089 | 0.354 |
| S2 all bands, known-bad temperatures removed (none) | OLS | 89 | -0.0683 | <0.001 | 0.862 | 0.089 | 0.354 |
| S3 S2, countries with >=10 bands | OLS | 32 | -0.0702 | 0.106 | 0.788 | 0.131 | 0.272 |
| S4 S2, log(rate) | OLS log(rate) | 89 | -0.0892 | <0.001 | 0.096 | 0.047 | 0.471 |
| S5 S2, count model | Poisson+robust SE (disp=34) | 89 | -0.0405 | 0.244 | 0.310 | 0.032 |  |
| S6 S3, count model | Poisson+robust SE (disp=71) | 32 | -0.0342 | 0.530 | 0.655 | 0.058 |  |
| S7 S2 without 'suspect' temperatures (Norway, Georgia) | OLS | 87 | -0.0675 | <0.001 | 0.816 | 0.098 | 0.35 |
| S8 S5 without 'suspect' temperatures | Poisson+robust SE (disp=35) | 87 | -0.0405 | 0.251 | 0.305 | 0.031 |  |

- بتای استاندارد (مدل اصلی): دما -0.43، GDP 0.28، اینترنت -0.01
- حذف تک‌تک کشورها: ضریب دما بین -0.074 و -0.058؛ بیشینه‌ی p = <0.001

## ۳. روند مضامین (بر اساس دوره‌ی تأسیس؛ مخرج = بندهای دارای مضمون)

### پوشش مضمون در هر دوره

| period | bands | with_themes | missing_pct |
|---|---|---|---|
| 1992-2009 | 274 | 246 | 10.2 |
| 2010-2014 | 380 | 318 | 16.3 |
| 2015-2019 | 316 | 248 | 21.5 |
| 2020-now | 626 | 459 | 26.7 |

| theme | 1992-2009 | 2010-2014 | 2015-2019 | 2020-now |
|---|---|---|---|---|
| depression | 45.5% (112/246) | 58.2% (185/318) | 61.7% (153/248) | 59.0% (271/459) |
| isolation | 4.9% (12/246) | 4.7% (15/318) | 2.4% (6/248) | 5.4% (25/459) |
| mental illness | 0.4% (1/246) | 3.5% (11/318) | 2.8% (7/248) | 5.2% (24/459) |
| misanthropy | 10.6% (26/246) | 12.9% (41/318) | 9.7% (24/248) | 10.5% (48/459) |
| nature | 14.6% (36/246) | 10.4% (33/318) | 6.5% (16/248) | 6.8% (31/459) |
| nihilism | 6.9% (17/246) | 4.7% (15/318) | 4.8% (12/248) | 3.9% (18/459) |
| self-harm | 0.8% (2/246) | 1.9% (6/318) | 0.8% (2/248) | 7.6% (35/459) |
| suicide | 32.9% (81/246) | 34.9% (111/318) | 35.5% (88/248) | 39.4% (181/459) |

### آزمون روند (اسپیرمن؛ بونفرونی = p < 0.00625)

| theme | spearman_rho | p | n | direction | significant_p<0.05 | significant_bonferroni |
|---|---|---|---|---|---|---|
| suicide | 0.059 | 0.03398 | 1271 | up | True | False |
| depression | 0.074 | 0.00844 | 1271 | up | True | False |
| mental illness | 0.087 | 0.00189 | 1271 | up | True | True |
| self-harm | 0.152 | 0.0 | 1271 | up | True | True |
| nature | -0.1 | 0.00036 | 1271 | down | True | True |
| misanthropy | -0.02 | 0.4721 | 1271 | down | False | False |
| nihilism | -0.038 | 0.17123 | 1271 | down | False | False |
| isolation | 0.027 | 0.34411 | 1271 | up | False | False |

## ۴. چرخه‌ی حیات (Kaplan-Meier؛ بندهای فعال censored)

| group | bands | split_up | censored_active | median_survival_years | survival_5y | survival_10y |
|---|---|---|---|---|---|---|
| pure DSBM | 853 | 197 | 656 | not reached by year 20 | 0.802 | 0.732 |
| hybrid | 517 | 77 | 440 | not reached by year 20 | 0.88 | 0.837 |

- آزمون log-rank (خالص در برابر ترکیبی): χ² = 16.547، p = <0.001

### سن از زمان تأسیس بر اساس وضعیت (توصیفی؛ طول عمر نیست)

| status_clean | count | mean | median |
|---|---|---|---|
| active | 1089 | 8.32 | 7.0 |
| changed name | 58 | 11.48 | 11.5 |
| disputed | 1 | 17.0 | 17.0 |
| on hold | 36 | 11.89 | 12.0 |
| split-up | 310 | 12.38 | 13.0 |
| unknown | 102 | 13.65 | 14.0 |

## ۵. ژانرهای همراه (خانواده‌ها)

| genre_family | bands | pct_of_all_bands |
|---|---|---|
| atmospheric black metal | 207 | 9.5 |
| post-black metal | 162 | 7.4 |
| ambient | 146 | 6.7 |
| raw black metal | 89 | 4.1 |
| doom metal | 67 | 3.1 |
| shoegaze | 37 | 1.7 |
| dark ambient | 26 | 1.2 |
| rock | 21 | 1.0 |
| experimental | 20 | 0.9 |
| post-rock | 19 | 0.9 |
| black metal | 16 | 0.7 |
| death metal | 9 | 0.4 |

### پرتکرارترین جفت‌ها

| genre_1 | genre_2 | co_occurrence_count |
|---|---|---|
| ambient | raw black metal | 9 |
| post-black metal | shoegaze | 8 |
| ambient | atmospheric black metal | 8 |
| ambient | experimental | 7 |
| post-black metal | post-rock | 4 |
| ambient | doom metal | 4 |
| post-rock | shoegaze | 4 |
| atmospheric black metal | post-black metal | 3 |
| doom metal | shoegaze | 3 |
| post-black metal | rock | 3 |

## ۶. جغرافیای مضامین (٪ بندهای دارای مضمون در هر کشور)

| country | depression | suicide | death | misanthropy | loneliness | melancholy | nature | sadness | solitude | sorrow | n_bands_with_themes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| United States | 60.3 | 41.2 | 11.8 | 9.5 | 9.5 | 5.7 | 7.3 | 4.2 | 3.8 | 6.5 | 262 |
| Russia | 53.7 | 30.6 | 13.9 | 3.7 | 13.0 | 5.6 | 8.3 | 4.6 | 3.7 | 7.4 | 108 |
| Brazil | 54.2 | 40.6 | 18.8 | 20.8 | 11.5 | 7.3 | 6.2 | 13.5 | 6.2 | 5.2 | 96 |
| Germany | 62.1 | 33.3 | 14.9 | 5.7 | 3.4 | 6.9 | 14.9 | 2.3 | 8.0 | 6.9 | 87 |
| Mexico | 59.7 | 43.5 | 14.5 | 11.3 | 22.6 | 21.0 | 14.5 | 6.5 | 8.1 | 9.7 | 62 |
| Italy | 49.2 | 39.3 | 18.0 | 11.5 | 11.5 | 16.4 | 6.6 | 3.3 | 19.7 | 3.3 | 61 |
| France | 47.3 | 12.7 | 18.2 | 10.9 | 7.3 | 10.9 | 10.9 | 7.3 | 10.9 | 10.9 | 55 |
| Canada | 45.1 | 27.5 | 19.6 | 13.7 | 3.9 | 7.8 | 9.8 | 7.8 | 2.0 | 2.0 | 51 |
| United Kingdom | 49.0 | 35.3 | 9.8 | 5.9 | 3.9 | 0.0 | 0.0 | 3.9 | 11.8 | 3.9 | 51 |
| Sweden | 57.1 | 35.7 | 7.1 | 11.9 | 7.1 | 4.8 | 7.1 | 9.5 | 9.5 | 2.4 | 42 |

## ۷. فرمت‌های انتشار

| period | releases | Full-length | EP | Demo | Split | Single | Compilation | Other |
|---|---|---|---|---|---|---|---|---|
| 1992-2009 | 469 | 20.3 | 7.5 | 52.9 | 14.7 | 2.8 | 1.7 | 0.2 |
| 2010-2014 | 1442 | 26.1 | 16.3 | 29.3 | 16.5 | 7.8 | 2.9 | 1.0 |
| 2015-2019 | 2197 | 31.7 | 22.3 | 15.1 | 10.2 | 16.1 | 3.5 | 1.2 |
| 2020-now | 6678 | 23.7 | 23.9 | 10.0 | 5.8 | 32.4 | 2.1 | 2.1 |

- انتشارهای یکتا: 10786؛ بندهای NO_RELEASES: 1 از 2186

## ۸. فصل‌بندی و روز هفته‌ی انتشار

- آلبوم‌ها: 10781؛ دارای ماه: 10375 (96.2٪)؛ دارای روز دقیق: 10103؛ تاریخ آینده (حذف‌شده): 1
- **آزمون اصلی فقط روی سال‌های کامل 2015–2025** است (سال جاری ناقص و رشد سالانه انتشارها، آزمون روی همه‌ی داده را مخدوش می‌کند). مورد انتظار متناسب با تعداد روزهای ماه است.

### آزمون ماه‌ها

| subset | n | chi2 | p | peak | low | max_min_ratio | winter_share_pct | winter_binomial_p |
|---|---|---|---|---|---|---|---|---|
| all releases (V3 method; biased) | 10374 | 32.96 | 0.00053 | Apr | Jun | 1.18 | 24.9 | 0.74135 |
| without 2026 (incomplete year) | 9563 | 33.24 | 0.00048 | Oct | May | 1.21 | 25.2 | 0.28603 |
| complete years 2015-2025  [PRIMARY] | 7986 | 22.96 | 0.01793 | Apr | Jun | 1.17 | 25.1 | 0.41379 |
| complete years 2020-2025 | 5824 | 15.57 | 0.15769 | Sep | Jun | 1.17 | 24.8 | 0.80798 |
| Full-length, complete years 2015-2025 | 2072 | 23.98 | 0.0128 | Apr | Jun | 1.41 | 24.3 | 0.70248 |
| EP, complete years 2015-2025 | 1878 | 7.99 | 0.71435 | Feb | Jul | 1.26 | 25.2 | 0.6302 |
| Single, complete years 2015-2025 | 2217 | 15.18 | 0.1742 | Feb | Mar | 1.29 | 25.3 | 0.49059 |
| Demo, complete years 2015-2025 | 918 | 15.11 | 0.17758 | Jul | Jun | 1.56 | 26.5 | 0.22079 |

- آزمون تجمعی درون‌سالی (هر سال با مجموع خودش): chi2=178.7 با 121 درجه آزادی، p=<0.001
- **جمع‌بندی ماه:** month effect: weak and unstable (significant only in 2015-onward, gone in 2020-onward; max/min ratio ~1.2; depends on the null used) - do not over-interpret
- **فرضیه‌ی «زمستان»:** not supported (binomial p=0.41379)

### روز هفته (فقط تاریخ‌های دارای روز دقیق)

| subset | n | friday_share_pct | friday_ci95 | friday_binomial_p | Mon | Tue | Wed | Thu | Fri | Sat | Sun |
|---|---|---|---|---|---|---|---|---|---|---|---|
| all exact dates | 10102 | 20.4 | 19.6-21.2 | 9.07e-62 | 1419 | 1297 | 1274 | 1322 | 2057 | 1389 | 1344 |
| all exact dates, without the 1st of the month | 9557 | 20.4 | 19.6-21.2 | 3.1e-59 | 1347 | 1215 | 1197 | 1255 | 1950 | 1318 | 1275 |
| complete years 2015-2025  [PRIMARY] | 7929 | 21.0 | 20.2-22.0 | 1.6300000000000002e-59 | 1098 | 998 | 991 | 1012 | 1669 | 1082 | 1079 |
| complete years 2015-2025, without the 1st | 7520 | 21.0 | 20.1-21.9 | 2.1799999999999998e-55 | 1043 | 936 | 935 | 964 | 1577 | 1034 | 1031 |
| period 1992-2009 | 253 | 18.6 | 14.3-23.8 | 0.0586 | 48 | 37 | 26 | 34 | 47 | 36 | 25 |
| period 2010-2014 | 1111 | 14.7 | 12.7-16.9 | 0.7 | 176 | 159 | 152 | 168 | 163 | 161 | 132 |
| period 2015-2019 | 2131 | 17.0 | 15.5-18.6 | 0.000521 | 300 | 332 | 259 | 303 | 362 | 276 | 299 |
| period 2020-now | 6607 | 22.5 | 21.5-23.5 | 6.08e-71 | 895 | 769 | 837 | 817 | 1485 | 916 | 888 |
| type Full-length (all years) | 2634 | 24.2 | 22.6-25.9 | 3.39e-41 | 343 | 352 | 296 | 310 | 637 | 371 | 325 |
| type EP (all years) | 2265 | 18.9 | 17.4-20.6 | 1.21e-09 | 317 | 280 | 287 | 335 | 429 | 305 | 312 |
| type Single (all years) | 2599 | 20.7 | 19.1-22.3 | 1.24e-18 | 357 | 319 | 347 | 317 | 537 | 356 | 366 |
| type Demo (all years) | 1382 | 14.8 | 13.0-16.7 | 0.617 | 226 | 184 | 170 | 193 | 204 | 204 | 201 |
| type Split (all years) | 798 | 20.6 | 17.9-23.5 | 1.42e-06 | 129 | 104 | 106 | 111 | 164 | 96 | 88 |

- سهم «روز ۱ ماه» = 5.4٪ در برابر ≈3.3٪ مورد انتظار (بخشی احتمالاً تاریخ تقریبی است)؛ نتیجه‌ی جمعه بدون روز ۱ هم تغییر نمی‌کند.

### پوشش ماه در هر دوره (سوگیری: دوره‌های قدیمی‌تر کم‌پوشش‌تر)

| period | albums | with_month | month_known_pct |
|---|---|---|---|
| 1992-2009 | 469 | 332 | 70.8 |
| 2010-2014 | 1441 | 1245 | 86.4 |
| 2015-2019 | 2197 | 2162 | 98.4 |
| 2020-now | 6674 | 6636 | 99.4 |
