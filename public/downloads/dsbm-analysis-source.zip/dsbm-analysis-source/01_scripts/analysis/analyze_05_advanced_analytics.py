"""Band longevity (Kaplan-Meier), genre network, thematic geography.

Fixes vs the first version
  * reference year is dynamic (was hard-coded 2024)
  * "longevity" uses the real active span from `years_active` and a survival analysis: active bands are
    CENSORED (they have not ended), so comparing 'age' of active vs split-up bands is no longer misleading
  * genre network: every DSBM spelling is removed ('depressive', 'depressive black', '(early)'...), companion genres are
    grouped into families -> no more fragment nodes. No networkx/seaborn needed.
  * thematic geography: denominator = bands WITH themes in that country; International/Unknown excluded; n shown
"""
import json
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa
from stats_utils import kaplan_meier, survival_at, logrank

clean = pd.read_csv(PROC / "dsbm_clean.csv")
enr = pd.read_csv(RAW / "dsbm_enriched.csv", usecols=["ma_id", "years_active"])
df = clean.merge(enr, on="ma_id", how="left")
summary = {"reference_year": CURRENT_YEAR}

# ── 1. longevity: Kaplan-Meier, pure DSBM vs hybrid ───────────────────
ya = df["years_active"].apply(parse_years_active)
df["start"] = [a if a is not None else f for (a, _), f in zip(ya, df.formed_year)]
df["end"] = [b for _, b in ya]
d = df[df.status_clean.isin(["active", "split-up"]) & df.start.notna()].copy()
d["event"] = (d.status_clean == "split-up").astype(int)
# split-up with no usable end year -> cannot measure the duration: drop
d = d[~((d.event == 1) & d.end.isna())]
d["duration"] = np.where(d.event == 1, d.end - d.start + 1, CURRENT_YEAR - d.start + 1).astype(float)
d = d[d.duration >= 1]
summary["longevity_n"] = int(len(d)); summary["longevity_events"] = int(d.event.sum())

groups = {"pure DSBM": d[d.is_pure_dsbm], "hybrid": d[~d.is_pure_dsbm]}
rows, kms = [], {}
for name, g in groups.items():
    km = kaplan_meier(g.duration, g.event); kms[name] = km
    rows.append({"group": name, "bands": len(g), "split_up": int(g.event.sum()), "censored_active": int((1 - g.event).sum()),
                 "median_survival_years": (km["median"] if km["median"] is not None and km["median"] <= 20 else "not reached by year 20"), "survival_5y": round(survival_at(km, 5), 3),
                 "survival_10y": round(survival_at(km, 10), 3)})
chi2, p = logrank(groups["pure DSBM"].duration.values, groups["pure DSBM"].event.values,
                  groups["hybrid"].duration.values, groups["hybrid"].event.values)
summary["logrank_pure_vs_hybrid"] = {"chi2": round(float(chi2), 3), "p": round(float(p), 5)}
pd.DataFrame(rows).to_csv(RESULTS / "longevity_km_summary.csv", index=False)
age = (df[df.formed_year.notna()].assign(age=lambda x: CURRENT_YEAR - x.formed_year)
         .groupby("status_clean").age.agg(["count", "mean", "median"]).round(2).reset_index())
age.to_csv(RESULTS / "age_since_formation_by_status.csv", index=False)
print(pd.DataFrame(rows).to_string(index=False)); print("log-rank:", summary["logrank_pure_vs_hybrid"])

fig, ax = plt.subplots(figsize=(9, 6))
for (name, km), col in zip(kms.items(), ("darkred", "steelblue")):
    t = np.concatenate([[0], km["t"]]); s = np.concatenate([[1], km["surv"]])
    ax.step(t, s, where="post", label=f"{name} (n={len(groups[name])})", color=col, lw=2)
ax.set(xlim=(0, 20), ylim=(0, 1.02), xlabel="Years since formation (active bands are censored)", ylabel="Share of bands still active",
       title=f"Band survival: pure DSBM vs hybrid (log-rank p={'<0.001' if p < 0.001 else format(p, '.3f')})")
ax.grid(alpha=.3); ax.legend(); plt.tight_layout(); plt.savefig(FIGS / "11_longevity_km.png", dpi=150); plt.close()

# ── 2. genre network (companion families) ─────────────────────────────
df["fam"] = df.genres_detail.apply(genre_families)
cnt = Counter(g for l in df.fam for g in l)
top = [g for g, _ in cnt.most_common(12)]
pd.DataFrame([(g, c, round(c / len(df) * 100, 1)) for g, c in cnt.most_common(25)],
             columns=["genre_family", "bands", "pct_of_all_bands"]).to_csv(RESULTS / "genre_family_counts.csv", index=False)
edges = Counter()
for l in df.fam:
    for a, b in combinations(sorted(set(x for x in l if x in top)), 2):
        edges[(a, b)] += 1
E = [(a, b, w) for (a, b), w in edges.items() if w >= 3]
pd.DataFrame(sorted(E, key=lambda x: -x[2]), columns=["genre_1", "genre_2", "co_occurrence_count"]).to_csv(
    RESULTS / "genre_network_edges.csv", index=False)
n = len(top); ang = np.linspace(0, 2 * np.pi, n, endpoint=False); pos = {g: (np.cos(a), np.sin(a)) for g, a in zip(top, ang)}
fig, ax = plt.subplots(figsize=(11, 10)); wmax = max([w for *_, w in E], default=1)
for a, b, w in E:
    ax.plot([pos[a][0], pos[b][0]], [pos[a][1], pos[b][1]], color="gray", alpha=.45, lw=0.6 + 5 * w / wmax, zorder=1)
for g in top:
    ax.scatter(*pos[g], s=60 + 3000 * cnt[g] / max(cnt.values()), color="skyblue", edgecolor="k", zorder=2)
    ax.annotate(f"{g}\n({cnt[g]})", pos[g], xytext=(pos[g][0] * 1.32, pos[g][1] * 1.22), ha="center", va="center", fontsize=9)
ax.set_xlim(-1.8, 1.8); ax.set_ylim(-1.6, 1.6); ax.axis("off")
ax.set_title(f"Companion genres of DSBM bands (families; line width = co-occurrence, min 3)\n"
             f"{int((df.fam.apply(len) > 0).sum())} of {len(df)} bands list at least one other genre")
plt.tight_layout(); plt.savefig(FIGS / "12_genre_network.png", dpi=150); plt.close()
summary["bands_with_companion_genre"] = int((df.fam.apply(len) > 0).sum())

# ── 3. thematic geography ─────────────────────────────────────────────
t = df[df.themes.notna() & ~df.country_clean.isin(NON_COUNTRIES)].copy(); t["tl"] = t.themes.apply(split_list)
top_c = t.country_clean.value_counts().head(10).index.tolist()
top_t = [x for x, _ in Counter(x for l in t.tl for x in l).most_common(10)]
M = pd.DataFrame({th: [t[t.country_clean == c].tl.apply(lambda l: th in l).mean() * 100 for c in top_c] for th in top_t}, index=top_c)
ns = [int((t.country_clean == c).sum()) for c in top_c]
M.round(1).assign(n_bands_with_themes=ns).rename_axis("country").to_csv(RESULTS / "thematic_geography_matrix.csv")
fig, ax = plt.subplots(figsize=(12, 7)); im = ax.imshow(M.values, cmap="YlOrRd", aspect="auto"); plt.colorbar(im, label="% of bands with themes")
ax.set_xticks(range(len(top_t))); ax.set_xticklabels(top_t, rotation=35, ha="right")
ax.set_yticks(range(len(top_c))); ax.set_yticklabels([f"{c} (n={k})" for c, k in zip(top_c, ns)])
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j, i, f"{M.values[i, j]:.0f}", ha="center", va="center", fontsize=8)
ax.set_title("Thematic geography: top 10 countries x top 10 themes (denominator: bands with themes)")
plt.tight_layout(); plt.savefig(FIGS / "13_thematic_geography.png", dpi=150); plt.close()
(RESULTS / "advanced_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary))
