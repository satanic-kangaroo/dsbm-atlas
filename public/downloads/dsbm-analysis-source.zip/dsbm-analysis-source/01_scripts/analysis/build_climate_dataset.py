"""Download (or read locally) country temperatures -> 02_data/raw/climate_country.csv   [NEEDS INTERNET]

Fixes vs. v1
  * canonical names (Türkiye->Turkey ...) + alias table -> Turkey/Czechia/South Korea/N. Macedonia are matched
  * 'X (Europe)' series are preferred (Denmark incl. Greenland gave -16.9 C; France incl. overseas territories)
  * the real data window is detected and written to the output (the GitHub/Kaggle mirror ends ~2013,
    so the old label "1991-2020" was wrong). Use --csv with a newer Berkeley Earth / ERA5 export if you have one.
  * sanity checks: identical temperatures for different countries, months-per-year coverage
Usage:
  python build_climate_dataset.py [--csv path/to/GlobalLandTemperaturesByCountry.csv] [--start 1991] [--end 2020]
"""
import argparse
import io
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

DEFAULT_URL = ("https://raw.githubusercontent.com/esoc214/fall2020_002_class_scripts/main/data/"
               "GlobalLandTemperaturesByCountry.csv")


def find_series(names_lower, country):
    """Candidate source names for a canonical country name, best first."""
    base = BERKELEY_ALIAS.get(country, country)
    return [f"{base} (Europe)".lower(), base.lower()]


def country_temperature(temp_df, country, start, end):
    """Mean of monthly values in [start,end] for `country`; (value, window_str, source_name) or (None,...)."""
    for cand in find_series(None, country):
        sub = temp_df[temp_df["_c"] == cand]
        sub = sub[(sub.year >= start) & (sub.year <= end)].dropna(subset=["AverageTemperature"])
        if len(sub):
            # average of yearly means (avoids over-weighting years with more months present)
            val = sub.groupby("year")["AverageTemperature"].mean().mean()
            return round(float(val), 2), f"{int(sub.year.min())}-{int(sub.year.max())}", cand
    return None, "", ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv"); ap.add_argument("--url", default=DEFAULT_URL)
    ap.add_argument("--start", type=int, default=1991); ap.add_argument("--end", type=int, default=2020)
    a = ap.parse_args()

    bands = pd.read_csv(PROC / "dsbm_clean.csv")
    countries = sorted(c for c in bands.country_clean.dropna().unique() if c not in NON_COUNTRIES)
    if a.csv:
        tdf = pd.read_csv(a.csv)
    else:
        print("downloading", a.url)
        tdf = pd.read_csv(io.StringIO(fetch_text(a.url, timeout=90)))
    tdf["dt"] = pd.to_datetime(tdf["dt"], errors="coerce")
    tdf["year"] = tdf.dt.dt.year
    tdf["_c"] = tdf["Country"].str.lower().str.strip()
    last_year = int(tdf.dropna(subset=["AverageTemperature"]).year.max())
    print(f"data available up to {last_year}; requested window {a.start}-{a.end}")
    if last_year < a.end:
        print(f"WARNING: data ends {last_year} < {a.end}: the window label will be {a.start}-{last_year}")

    try:
        import country_converter as coco
        cc = coco.CountryConverter()
        iso = lambda n: ISO3_MANUAL.get(n) or (lambda x: x if x != "not found" else None)(cc.convert(n, to="ISO3"))
    except ImportError:
        old = pd.read_csv(RAW / "climate_country.csv") if (RAW / "climate_country.csv").exists() else pd.DataFrame(columns=["country_clean", "iso3"])
        m = dict(zip(old.country_clean.map(canon_country), old.iso3))
        iso = lambda n: ISO3_MANUAL.get(n) or m.get(n)

    rows = []
    for c in countries:
        v, win, src = country_temperature(tdf, c, a.start, a.end)
        rows.append({"country_clean": c, "iso3": iso(c), "avg_temp_c": v,
                     "temp_source": f"BerkeleyEarth:{src}" if v is not None else "not_found", "temp_window": win})
    out = pd.DataFrame(rows)
    dup = out.dropna(subset=["avg_temp_c"]).groupby("avg_temp_c").country_clean.apply(list)
    for v, lst in dup[dup.apply(len) > 1].items():
        print(f"WARNING: identical temperature {v} for {lst} -> check name matching")
    print("not found:", out[out.avg_temp_c.isna()].country_clean.tolist())
    out.to_csv(RAW / "climate_country.csv", index=False)
    print(f"saved {len(out)} rows -> {RAW / 'climate_country.csv'}")
    print("Now update 02_data/raw/temp_flags.csv (remove flags you have fixed) and re-run build_regression_dataset.py")


if __name__ == "__main__":
    main()
