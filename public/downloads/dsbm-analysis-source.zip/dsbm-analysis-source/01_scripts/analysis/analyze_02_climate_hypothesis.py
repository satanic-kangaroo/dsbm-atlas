"""Simple temperature <-> DSBM-rate test (all countries that have a temperature)."""
import json
import sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa
from stats_utils import ols, poisson

df = pd.read_csv(PROC / "regression_dataset.csv").dropna(subset=["avg_temp_c", "bands_per_million"])
clean = df[df.temp_flag.ne("bad")]          # drop temperatures known to be wrong
out = {}
for label, d in (("all_with_temp", df), ("excl_bad_temp", clean), ("excl_bad_temp_min10", clean[clean.band_count >= 10])):
    r, p = stats.pearsonr(d.avg_temp_c, d.bands_per_million)
    rho, ps = stats.spearmanr(d.avg_temp_c, d.bands_per_million)
    m = ols(d[["avg_temp_c"]], d.bands_per_million, ["temp"])
    out[label] = {"n": int(len(d)), "pearson_r": round(r, 3), "pearson_p": round(p, 5),
                  "spearman_rho": round(rho, 3), "spearman_p": round(ps, 5),
                  "ols_slope": round(m["coef"]["temp"], 4), "ols_p_HC3": round(m["p_robust"]["temp"], 5),
                  "r2": round(m["r2"], 3)}
    print(label, out[label])
# count model without controls (Poisson, offset log(pop), robust SE)
for label, d in (("poisson_excl_bad_temp", clean), ("poisson_excl_bad_temp_min10", clean[clean.band_count >= 10])):
    m = poisson(d[["avg_temp_c"]], d.band_count, np.log(d.population_m), ["temp"])
    out[label] = {"n": int(m["n"]), "coef": round(m["coef"]["temp"], 4), "pct_per_C": round((np.exp(m["coef"]["temp"]) - 1) * 100, 1),
                  "p_robust": round(m["p_robust"]["temp"], 5), "dispersion": round(m["dispersion"], 1)}
    print(label, out[label])
(RESULTS / "climate_simple.json").write_text(json.dumps(out, indent=2))

# scatter: bubble size = number of bands; flagged countries marked
d = clean
m = ols(d[["avg_temp_c"]], d.bands_per_million, ["temp"])
xs = np.linspace(df.avg_temp_c.min(), df.avg_temp_c.max(), 50)
fig, ax = plt.subplots(figsize=(12, 7))
ax.scatter(d.avg_temp_c, d.bands_per_million, s=20 + d.band_count * 2.5, alpha=.55, color="teal", edgecolor="k", linewidth=.3, label="country (size = no. of bands)")
bad = df[df.temp_flag.eq("bad")]
ax.scatter(bad.avg_temp_c, bad.bands_per_million, marker="x", color="red", s=80, label="temperature flagged bad (excluded)")
ax.plot(xs, m["coef"]["const"] + m["coef"]["temp"] * xs, color="darkred", lw=2, label=f"OLS (n={m['n']}), slope={m['coef']['temp']:.3f}, p_HC3={'<0.001' if m['p_robust']['temp']<0.001 else format(m['p_robust']['temp'],'.3f')}")
for _, r in df.iterrows():
    if r.bands_per_million > 1.7 or r.avg_temp_c < -2 or r.band_count > 80:
        ax.annotate(f"{r.country_clean} ({int(r.band_count)})", (r.avg_temp_c, r.bands_per_million), xytext=(4, 3), textcoords="offset points", fontsize=8)
ax.set(title="DSBM bands per million vs. mean annual temperature", xlabel="Mean annual temperature (°C)  [see README: data window]", ylabel="DSBM bands per million")
ax.grid(alpha=.3); ax.legend(); plt.tight_layout(); plt.savefig(FIGS / "07_climate_hypothesis.png", dpi=150); plt.close()
