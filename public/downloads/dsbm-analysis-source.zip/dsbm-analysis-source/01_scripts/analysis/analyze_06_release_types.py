"""Release formats over time.  Input: 02_data/raw/dsbm_discography.csv

Fixes vs the first version: exact duplicates and (when album_id exists) splits listed under two bands are
counted ONCE; fixed periods with n on the plot instead of 'decades' (only 5 releases before 2000);
a data-quality block says when the table is provisional (bands wrongly recorded as NO_RELEASES / no album_id yet).
Outputs: 04_results/release_types_by_period.csv, release_types_meta.json, 03_figures/14_release_types.png
"""
import json
import sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

raw = pd.read_csv(RAW / "dsbm_discography.csv", dtype={"album_id": str})
for c in ("album_id", "album_url"):
    if c not in raw.columns:
        raw[c] = ""
raw["album_id"] = raw["album_id"].fillna("")
bands_total = raw.ma_id.nunique()
empty_bands = raw[raw.album == "NO_RELEASES"].ma_id.nunique()
rel = raw[raw.album != "NO_RELEASES"].copy()
n_rows = len(rel)
has_id = rel.album_id != ""
# 1) with album_id: one row per album (splits shared by two bands collapse); 2) without: drop exact duplicates
rel = pd.concat([rel[has_id].drop_duplicates("album_id"),
                 rel[~has_id].drop_duplicates(["ma_id", "album", "type", "year_raw"])])
meta = {"bands_in_discography_file": int(bands_total), "bands_recorded_NO_RELEASES": int(empty_bands),
        "no_release_share_pct": round(empty_bands / bands_total * 100, 1), "release_rows": int(n_rows),
        "unique_releases": int(len(rel)), "rows_without_album_id": int((~has_id).sum())}
meta["rows_without_album_id_pct"] = round(meta["rows_without_album_id"] / max(n_rows, 1) * 100, 2)
meta["provisional"] = bool(meta["no_release_share_pct"] > 5 or meta["rows_without_album_id_pct"] > 0.5)
meta["why_provisional"] = [m for m, c in (
    (f"{empty_bands} bands ({meta['no_release_share_pct']}%) have NO_RELEASES - the discography table is incomplete", meta["no_release_share_pct"] > 5),
    ("album_id missing for many rows: splits between two DSBM bands would be counted twice", meta["rows_without_album_id_pct"] > 0.5)) if c]
meta["minor_notes"] = ([f"{meta['rows_without_album_id']} release rows ({meta['rows_without_album_id_pct']}%) have no album_id - negligible"]
                       if 0 < meta["rows_without_album_id_pct"] <= 0.5 else [])

rel = rel.dropna(subset=["year"]).copy(); rel["year"] = rel.year.astype(int)
rel["period"] = rel.year.apply(period_of)
rel["type_c"] = rel["type"].astype(str).str.strip().str.lower().map(
    {"full-length": "Full-length", "ep": "EP", "demo": "Demo", "split": "Split", "single": "Single", "compilation": "Compilation"}).fillna("Other")
names = [p[0] for p in PERIODS]; order = ["Full-length", "EP", "Demo", "Split", "Single", "Compilation", "Other"]
ct = rel.groupby(["period", "type_c"]).size().unstack(fill_value=0).reindex(index=names, columns=order, fill_value=0)
pct = ct.div(ct.sum(axis=1), axis=0).mul(100).round(1)
out = pct.copy(); out.insert(0, "releases", ct.sum(axis=1)); out.to_csv(RESULTS / "release_types_by_period.csv")
(RESULTS / "release_types_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
print(json.dumps(meta, indent=1)); print(out.to_string())

fig, ax = plt.subplots(figsize=(11, 6.5)); bottom = np.zeros(len(names))
for t in order:
    ax.bar(names, pct[t].values, bottom=bottom, label=t); bottom += pct[t].values
ax.set_xticks(range(len(names))); ax.set_xticklabels([f"{n}\n(n={int(v)})" for n, v in zip(names, ct.sum(axis=1))])
ax.set(ylabel="% of releases in period", xlabel="Release period",
       title="Release formats of DSBM bands" + ("  [PROVISIONAL DATA - see README]" if meta["provisional"] else ""))
ax.legend(bbox_to_anchor=(1.01, 1), loc="upper left"); plt.tight_layout(); plt.savefig(FIGS / "14_release_types.png", dpi=150); plt.close()
