"""Lyrical-theme trends by formation period.
Fixes vs the first version: denominator = bands that HAVE themes (34% have none, and that share changes with
period), fixed 4 periods instead of decades (only 9 bands formed in the 1990s), Wilson 95% CIs, a trend test,
n shown on every point.  Outputs: 04_results/theme_trends.csv, theme_trend_tests.csv, 03_figures/10_theme_trends.png
"""
import sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

KEY_THEMES = ["suicide", "depression", "mental illness", "self-harm", "nature", "misanthropy", "nihilism", "isolation"]
df = pd.read_csv(PROC / "dsbm_clean.csv").dropna(subset=["formed_year"]).copy()
df["period"] = df.formed_year.apply(period_of)
df["has_themes"] = df.themes.notna()
df["tl"] = df.themes.apply(split_list)
names = [p[0] for p in PERIODS]

cov = (df.groupby("period").agg(bands=("ma_id", "count"), with_themes=("has_themes", "sum"))
         .reindex(names).assign(missing_pct=lambda x: (1 - x.with_themes / x.bands) * 100).round(1))
cov.to_csv(RESULTS / "theme_coverage_by_period.csv")
print("bands with a formation year:", len(df)); print(cov.to_string())

t = df[df.has_themes]
rows, tests = [], []
for th in KEY_THEMES:
    y = t.tl.apply(lambda l: th in l).astype(int)
    for p in names:
        sub = y[t.period == p]; k, n = int(sub.sum()), int(len(sub))
        lo, hi = wilson(k, n)
        rows.append({"period": p, "theme": th, "bands_with_theme": k, "bands_with_any_theme": n,
                     "pct": round(k / n * 100, 1) if n else np.nan, "ci_low": round(lo * 100, 1), "ci_high": round(hi * 100, 1)})
    rho, p = stats.spearmanr(t.formed_year, y)
    tests.append({"theme": th, "spearman_rho": round(rho, 3), "p": round(p, 5), "n": int(len(y)),
                  "direction": "up" if rho > 0 else "down", "significant_p<0.05": bool(p < 0.05),
                  "significant_bonferroni": bool(p < 0.05 / len(KEY_THEMES))})
tr = pd.DataFrame(rows); te = pd.DataFrame(tests)
tr.to_csv(RESULTS / "theme_trends.csv", index=False); te.to_csv(RESULTS / "theme_trend_tests.csv", index=False)
print(te.to_string(index=False))

fig, axes = plt.subplots(2, 4, figsize=(16, 7), sharex=True)
for ax, th in zip(axes.ravel(), KEY_THEMES):
    s = tr[tr.theme == th].set_index("period").reindex(names)
    ax.errorbar(range(len(names)), s.pct, yerr=[s.pct - s.ci_low, s.ci_high - s.pct], marker="o", capsize=3, color="purple")
    r = te[te.theme == th].iloc[0]
    ax.set_title(f"{th}\nrho={r.spearman_rho:+.2f}, p={r.p:.3f}", fontsize=10)
    ax.set_xticks(range(len(names))); ax.set_xticklabels([f"{n}\n(n={int(v)})" for n, v in zip(names, s.bands_with_any_theme)], fontsize=7)
    ax.set_ylim(bottom=0); ax.grid(alpha=.3)
axes[0, 0].set_ylabel("% of bands with themes"); axes[1, 0].set_ylabel("% of bands with themes")
fig.suptitle("Lyrical themes by formation period (bars = 95% Wilson CI; n = bands with themes listed)")
plt.tight_layout(); plt.savefig(FIGS / "10_theme_trends.png", dpi=150); plt.close()
