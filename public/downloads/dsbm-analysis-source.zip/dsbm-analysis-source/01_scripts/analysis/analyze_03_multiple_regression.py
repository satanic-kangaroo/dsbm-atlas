"""Multiple regression + robustness grid.  The headline result must survive these checks."""
import json
import sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import zscore

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa
from stats_utils import ols, poisson

COLS = ["avg_temp_c", "gdp_per_capita", "internet_pct"]
d0 = pd.read_csv(PROC / "regression_dataset.csv").dropna(subset=COLS + ["bands_per_million"]).copy()
d0["gdp_10k"] = d0.gdp_per_capita / 1e4
d0["net_10"] = d0.internet_pct / 10
print(f"{len(d0)} countries with complete data")

def ols_spec(name, d, y="bands_per_million", log=False):
    yy = np.log(d[y]) if log else d[y]
    m = ols(d[["avg_temp_c", "gdp_10k", "net_10"]], yy, ["temp", "gdp_10k", "internet_10pp"])
    return {"spec": name, "model": "OLS" + (" log(rate)" if log else ""), "n": m["n"],
            "temp_coef": m["coef"]["temp"], "temp_p": m["p_robust"]["temp"],
            "temp_ci_low": float(m["ci_robust"]["temp"][0]), "temp_ci_high": float(m["ci_robust"]["temp"][1]), "internet_p": m["p_robust"]["internet_10pp"],
            "gdp_p": m["p_robust"]["gdp_10k"], "r2": m["r2"]}

def pois_spec(name, d):
    m = poisson(d[["avg_temp_c", "gdp_10k", "net_10"]], d.band_count, np.log(d.population_m),
                ["temp", "gdp_10k", "internet_10pp"])
    b = m["coef"]["temp"]
    return {"spec": name, "model": f"Poisson+robust SE (disp={m['dispersion']:.0f})", "n": m["n"],
            "temp_coef": b, "temp_p": m["p_robust"]["temp"], "temp_ci_low": float(m["ci_robust"]["temp"][0]), "temp_ci_high": float(m["ci_robust"]["temp"][1]),
            "internet_p": m["p_robust"]["internet_10pp"], "gdp_p": m["p_robust"]["gdp_10k"],
            "r2": np.nan, "temp_pct_per_C": (np.exp(b) - 1) * 100}

bad_names = ", ".join(d0.loc[d0.temp_flag.eq("bad"), "country_clean"]) or "none"
good = d0[d0.temp_flag.ne("bad")]
print(f"countries excluded for known-bad temperature: {bad_names}")
big = good[good.band_count >= 10]
clean_t = good[good.temp_flag.isna()]          # also drop 'suspect' temperatures
sus_names = ", ".join(good.loc[good.temp_flag.notna(), "country_clean"]) or "none"
legacy = d0.copy(); legacy["bands_per_million"] = legacy.bands_per_million_legacy

rows = [
    ols_spec("S0 legacy count: bands with year only", legacy),
    ols_spec("S1 all bands counted (no exclusions)", d0),
    ols_spec(f"S2 all bands, known-bad temperatures removed ({bad_names})  [PRIMARY OLS]", good),
    ols_spec("S3 S2, countries with >=10 bands", big),
    ols_spec("S4 S2, log(rate)", good, log=True),
    pois_spec("S5 S2, count model  [PRIMARY COUNT MODEL]", good),
    pois_spec("S6 S3, count model", big),
    ols_spec(f"S7 S2 without 'suspect' temperatures ({sus_names})", clean_t),
    pois_spec(f"S8 S5 without 'suspect' temperatures", clean_t),
]
res = pd.DataFrame(rows)
res.to_csv(RESULTS / "robustness_grid.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 70)
print(res[["spec", "model", "n", "temp_coef", "temp_p", "internet_p", "gdp_p", "r2"]].round(4).to_string(index=False))

# standardized betas for the primary OLS
dz = good[COLS + ["bands_per_million"]].apply(zscore)
mz = ols(dz[COLS], dz.bands_per_million, COLS)
betas = {k: round(mz["coef"][k], 3) for k in COLS}
print("standardized betas (S2):", betas)

# leave-one-out on the temperature coefficient (S2)
loo = []
for i in good.index:
    m = ols(good.drop(i)[["avg_temp_c", "gdp_10k", "net_10"]], good.drop(i).bands_per_million, ["t", "g", "n"])
    loo.append((good.loc[i, "country_clean"], m["coef"]["t"], m["p_robust"]["t"]))
loo = pd.DataFrame(loo, columns=["dropped", "temp_coef", "temp_p"])
print(f"LOO (S2): coef {loo.temp_coef.min():.3f}..{loo.temp_coef.max():.3f}; "
      f"p max {loo.temp_p.max():.3f} (dropping {loo.loc[loo.temp_p.idxmax(), 'dropped']})")
loo.to_csv(RESULTS / "loo_temperature.csv", index=False)
corr = d0[COLS + ["bands_per_million"]].corr()

json.dump({"standardized_betas_S2": betas, "loo_coef_range": [loo.temp_coef.min(), loo.temp_coef.max()],
           "loo_max_p": loo.temp_p.max(), "corr": corr.round(3).to_dict()},
          open(RESULTS / "multiple_regression_extra.json", "w"), indent=2)

# figures
fig, ax = plt.subplots(figsize=(8, 6))
im = ax.imshow(corr.values, cmap="coolwarm", vmin=-1, vmax=1)
ax.set_xticks(range(4)); ax.set_yticks(range(4)); ax.set_xticklabels(corr.columns, rotation=30, ha="right"); ax.set_yticklabels(corr.columns)
for i in range(4):
    for j in range(4):
        ax.text(j, i, f"{corr.values[i, j]:.2f}", ha="center", va="center")
plt.colorbar(im); ax.set_title("Correlation matrix: climate, economy, DSBM rate"); plt.tight_layout()
plt.savefig(FIGS / "08_correlation_matrix.png", dpi=150); plt.close()

fig, ax = plt.subplots(figsize=(10, 5))
lab = [r.spec.split(" (")[0].split("  [")[0][:60] for r in res.itertuples()]
cols = ["seagreen" if p < .05 else "indianred" for p in res.temp_p]
ax.barh(range(len(res)), -np.log10(res.temp_p), color=cols)
ax.axvline(-np.log10(.05), color="k", ls="--"); ax.text(-np.log10(.05), -0.7, " p=0.05", fontsize=8)
ax.set_yticks(range(len(res))); ax.set_yticklabels(lab, fontsize=8); ax.invert_yaxis()
ax.set(xlabel="-log10(p) of temperature coefficient (robust SE)", title="Is the temperature effect robust? (green = p<0.05)")
plt.tight_layout(); plt.savefig(FIGS / "09_robustness.png", dpi=150); plt.close()
