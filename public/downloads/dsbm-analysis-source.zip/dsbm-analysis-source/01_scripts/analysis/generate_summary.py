"""Collects the numbers produced by the analysis scripts (04_results/*) into RESULTS_SUMMARY.md.
It does NOT recompute anything: every figure comes from a results file, so the summary can't drift from the analyses.
Run after the analysis scripts (run_all.sh does)."""
import json
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

OUT = ROOT / "RESULTS_SUMMARY.md"


def jload(name):
    p = RESULTS / name
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


def cload(name):
    p = RESULTS / name
    return pd.read_csv(p) if p.exists() else None


def fp(p):
    if p is None or p != p:
        return "-"
    return "<0.001" if p < 0.001 else f"{p:.3f}"


def fn(x, d=3):
    return "-" if x is None or x != x else f"{x:.{d}f}"


def md(df):
    if df is None or len(df) == 0:
        return "*no data*"
    cols = [str(c) for c in df.columns]
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join(["---"] * len(cols)) + "|"]
    lines += ["| " + " | ".join("" if (isinstance(v, float) and v != v) else str(v) for v in r) + " |" for r in df.values.tolist()]
    return "\n".join(lines)


L = ["# خلاصه‌ی نتایج پروژه DSBM (تولید خودکار)\n",
     "> همه‌ی اعداد از فایل‌های `04_results/` خوانده می‌شوند و در این اسکریپت دوباره محاسبه نمی‌شوند. "
     "تفسیر و محدودیت‌ها در `REPORT_fa.md` است.\n"]

# ── data quality banner ──
desc = jload("descriptive_summary.json") or {}
meta = jload("release_types_meta.json") or {}
warn = []
if meta.get("provisional"):
    warn += [f"- دیسکوگرافی **موقتی** است: {w}" for w in meta.get("why_provisional", [])]
warn += [f"- ℹ️ {w}" for w in meta.get("minor_notes", [])]
if desc.get("profiles_missing"):
    warn.append(f"- {desc['profiles_missing']} بند بدون رکورد پروفایل.")
if warn:
    L += ["## ⚠️ هشدارهای کیفیت داده\n", "\n".join(warn) + "\n"]

# ── 1. overview ──
L.append("## ۱. اطلاعات پایه\n")
if desc:
    L += [f"- تعداد بندها: **{desc['n_bands']}**",
          f"- بدون سال تأسیس: {desc['formed_year_missing']} ({desc['formed_year_missing_pct']}%)",
          f"- بدون مضمون: {desc['n_bands'] - desc['themes_available']} ({desc['themes_missing_pct']}%)",
          f"- بندهای «International/Unknown» (بدون کشور): {sum(desc.get('non_country_rows', {}).values())}",
          f"- خلوص ژانر: {desc['pure_dsbm']['pct']}% فقط DSBM",
          f"- وضعیت (٪ از کل): " + "، ".join(f"{k} {v}%" for k, v in desc["status_pct_of_all"].items()),
          f"- میانه‌ی سن بندهای فعال: {desc['median_age_active']} سال (سال مرجع {desc['age_reference_year']})", ""]
    L += ["### ۱۰ کشور برتر (خام)\n", md(pd.DataFrame(desc["top_countries_raw"].items(), columns=["country", "bands"])), ""]
    pc = pd.DataFrame([(k, v["bands"], v["per_million"]) for k, v in desc["per_capita_top"].items()], columns=["country", "bands", "per_million"])
    L += [f"### سرانه (حداقل {desc['per_capita_min_bands']} بند)\n", md(pc), ""]
    L += ["### سال‌های اوج تأسیس\n", md(pd.DataFrame(desc["peak_years"].items(), columns=["year", "bands"])), ""]
    u = desc["unsigned"]
    L += ["### بدون لیبل\n", md(pd.DataFrame([
        ("بندهای فعال (لیبل فعلی)", u["among_current_label_active_bands"]["unsigned"], u["among_current_label_active_bands"]["bands"], u["among_current_label_active_bands"]["pct"]),
        ("بندهای غیرفعال (آخرین لیبل)", u["among_last_label_inactive_bands"]["unsigned"], u["among_last_label_inactive_bands"]["bands"], u["among_last_label_inactive_bands"]["pct"]),
        ("همه", u["all_profiles"]["unsigned"], u["all_profiles"]["bands"], u["all_profiles"]["pct"])],
        columns=["group", "unsigned", "bands", "pct"])), ""]
    L.append(f"- مضامین صریحاً اقلیمی: {desc['themes_climate_explicit']['pct_of_bands_with_themes']}% از بندهای دارای مضمون؛ "
             f"طبیعت {desc['themes_nature']['pct_of_bands_with_themes']}%؛ گرم {desc['themes_warm']['pct_of_bands_with_themes']}%؛ "
             f"روان‌شناختی {desc['themes_psychological']['pct_of_bands_with_themes']}%\n")

# ── 3. climate ──
L.append("## ۲. آزمون فرضیه‌ی اقلیمی\n")
cs = jload("climate_simple.json")
if cs:
    rows = []
    for k, v in cs.items():
        if "pearson_r" in v:
            rows.append((k, v["n"], v["pearson_r"], v["spearman_rho"], v["ols_slope"], fp(v["ols_p_HC3"]), v["r2"]))
    L += ["### رابطه‌ی ساده (OLS، خطای HC3)\n", md(pd.DataFrame(rows, columns=["spec", "n", "pearson_r", "spearman_rho", "slope", "p_HC3", "R2"])), ""]
    rows = [(k, v["n"], v["pct_per_C"], fp(v["p_robust"]), v["dispersion"]) for k, v in cs.items() if "pct_per_C" in v]
    L += ["### مدل شمارشی ساده (پواسون با offset جمعیت)\n", md(pd.DataFrame(rows, columns=["spec", "n", "pct_change_per_C", "p_robust", "dispersion"])), ""]
rg = cload("robustness_grid.csv")
if rg is not None:
    t = pd.DataFrame({"spec": rg.spec.str.replace(r"\s+\[.*\]", "", regex=True), "model": rg.model, "n": rg.n,
                      "temp_coef": rg.temp_coef.round(4), "temp_p": rg.temp_p.apply(fp), "internet_p": rg.internet_p.apply(fp),
                      "gdp_p": rg.gdp_p.apply(fp), "R2": rg.r2.round(3)})
    L += ["### جدول حساسیت (رگرسیون با کنترل GDP و اینترنت)\n", md(t), ""]
ex = jload("multiple_regression_extra.json")
if ex:
    b = ex["standardized_betas_S2"]
    L.append(f"- بتای استاندارد (مدل اصلی): دما {b['avg_temp_c']:.2f}، GDP {b['gdp_per_capita']:.2f}، اینترنت {b['internet_pct']:.2f}")
    L.append(f"- حذف تک‌تک کشورها: ضریب دما بین {ex['loo_coef_range'][0]:.3f} و {ex['loo_coef_range'][1]:.3f}؛ بیشینه‌ی p = {fp(ex['loo_max_p'])}\n")

# ── 4. themes ──
L.append("## ۳. روند مضامین (بر اساس دوره‌ی تأسیس؛ مخرج = بندهای دارای مضمون)\n")
cov = cload("theme_coverage_by_period.csv"); tr = cload("theme_trends.csv"); te = cload("theme_trend_tests.csv")
if cov is not None:
    L += ["### پوشش مضمون در هر دوره\n", md(cov), ""]
if tr is not None:
    tr["cell"] = tr.pct.astype(str) + "% (" + tr.bands_with_theme.astype(str) + "/" + tr.bands_with_any_theme.astype(str) + ")"
    L += [md(tr.pivot(index="theme", columns="period", values="cell").reset_index()), ""]
if te is not None:
    L += ["### آزمون روند (اسپیرمن؛ بونفرونی = p < 0.00625)\n", md(te), ""]

# ── 5. longevity ──
L.append("## ۴. چرخه‌ی حیات (Kaplan-Meier؛ بندهای فعال censored)\n")
km = cload("longevity_km_summary.csv"); adv = jload("advanced_summary.json")
if km is not None:
    L += [md(km), ""]
    if adv:
        L.append(f"- آزمون log-rank (خالص در برابر ترکیبی): χ² = {adv['logrank_pure_vs_hybrid']['chi2']}، p = {fp(adv['logrank_pure_vs_hybrid']['p'])}\n")
ag = cload("age_since_formation_by_status.csv")
if ag is not None:
    L += ["### سن از زمان تأسیس بر اساس وضعیت (توصیفی؛ طول عمر نیست)\n", md(ag), ""]

# ── 6/7 genres & geography ──
L.append("## ۵. ژانرهای همراه (خانواده‌ها)\n")
gc = cload("genre_family_counts.csv"); ge = cload("genre_network_edges.csv")
if gc is not None:
    L += [md(gc.head(12)), ""]
if ge is not None:
    L += ["### پرتکرارترین جفت‌ها\n", md(ge.head(10)), ""]
L.append("## ۶. جغرافیای مضامین (٪ بندهای دارای مضمون در هر کشور)\n")
gm = cload("thematic_geography_matrix.csv")
L += [md(gm) if gm is not None else "*no data*", ""]

# ── 8. release formats ──
L.append("## ۷. فرمت‌های انتشار" + (" (موقتی)" if meta.get("provisional") else "") + "\n")
rt = cload("release_types_by_period.csv")
if rt is not None:
    L += [md(rt), ""]
    L.append(f"- انتشارهای یکتا: {meta.get('unique_releases')}؛ بندهای NO_RELEASES: {meta.get('bands_recorded_NO_RELEASES')} از {meta.get('bands_in_discography_file')}\n")

# ── 9. seasonality ──
L.append("## ۸. فصل‌بندی و روز هفته‌ی انتشار\n")
ss = jload("seasonality_summary.json")
if not ss or not ss.get("available"):
    L.append("*هنوز در دسترس نیست: جدول جزئیات آلبوم‌ها ارائه نشده است.*\n")
else:
    y0, y1 = ss["complete_years"]
    L.append(f"- آلبوم‌ها: {ss['albums']}؛ دارای ماه: {ss['month_known']} ({ss['month_known_pct']}٪)؛ دارای روز دقیق: {ss['day_known']}؛ تاریخ آینده (حذف‌شده): {ss['future_dated_excluded']}")
    L.append(f"- **آزمون اصلی فقط روی سال‌های کامل {y0}–{y1}** است (سال جاری ناقص و رشد سالانه انتشارها، آزمون روی همه‌ی داده را مخدوش می‌کند). مورد انتظار متناسب با تعداد روزهای ماه است.\n")
    mt = cload("seasonality_month_tests.csv")
    if mt is not None:
        L += ["### آزمون ماه‌ها\n", md(mt[["subset", "n", "chi2", "p", "peak", "low", "max_min_ratio", "winter_share_pct", "winter_binomial_p"]]), ""]
    pw = ss.get("pooled_within_year_chi2")
    if pw:
        L.append(f"- آزمون تجمعی درون‌سالی (هر سال با مجموع خودش): chi2={pw['chi2']} با {pw['dof']} درجه آزادی، p={fp(pw['p'])}")
    L.append(f"- **جمع‌بندی ماه:** {ss.get('interpretation')}")
    L.append(f"- **فرضیه‌ی «زمستان»:** {ss.get('winter_hypothesis')}\n")
    wk = cload("seasonality_weekday.csv")
    if wk is not None:
        L += ["### روز هفته (فقط تاریخ‌های دارای روز دقیق)\n", md(wk[["subset", "n", "friday_share_pct", "friday_ci95", "friday_binomial_p", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]]), ""]
    L.append(f"- سهم «روز ۱ ماه» = {ss['day1_share_pct']}٪ در برابر ≈{ss['day1_expected_pct']}٪ مورد انتظار (بخشی احتمالاً تاریخ تقریبی است)؛ نتیجه‌ی جمعه بدون روز ۱ هم تغییر نمی‌کند.\n")
    sc = cload("seasonality_coverage_by_period.csv")
    L += ["### پوشش ماه در هر دوره (سوگیری: دوره‌های قدیمی‌تر کم‌پوشش‌تر)\n", md(sc), ""] if sc is not None else []

OUT.write_text("\n".join(L), encoding="utf-8")
print("wrote", OUT)
