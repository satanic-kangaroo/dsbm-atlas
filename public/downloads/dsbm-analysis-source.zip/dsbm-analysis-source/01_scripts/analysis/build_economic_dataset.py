"""World Bank GDP per capita + internet users (%) -> 02_data/raw/worldbank_cache.csv   [NEEDS INTERNET]

Fixes vs. v1: the old code returned the FIRST year that had any data (so countries missing in 2022 stayed NaN
even though 2021/2020 existed). Now: fetch 2018-2023 and keep the latest non-null value per country;
the year used is stored. Chunked (WB limits multi-country queries). Covers all countries in regression_dataset.csv.
"""
import sys
import time
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

INDICATORS = {"gdp_per_capita": "NY.GDP.PCAP.CD", "internet_pct": "IT.NET.USER.ZS"}


def fetch_latest(code, iso_list, y0=2018, y1=2023, chunk=40):
    best = {}
    for i in range(0, len(iso_list), chunk):
        url = (f"https://api.worldbank.org/v2/country/{';'.join(iso_list[i:i+chunk])}/indicator/{code}"
               f"?format=json&date={y0}:{y1}&per_page=5000")
        for attempt in range(3):
            try:
                data = fetch_json(url, timeout=30)
                for it in (data[1] or []):
                    if it["value"] is not None:
                        y = int(it["date"])
                        if it["countryiso3code"] not in best or y > best[it["countryiso3code"]][0]:
                            best[it["countryiso3code"]] = (y, it["value"])
                break
            except Exception as e:
                print("retry", code, e); time.sleep(3)
    return best


def main():
    reg = pd.read_csv(PROC / "regression_dataset.csv")
    isos = sorted(reg.iso3.dropna().unique())
    out = pd.DataFrame({"iso3": isos})
    for col, code in INDICATORS.items():
        b = fetch_latest(code, isos)
        out[col] = out.iso3.map(lambda k: b.get(k, (None, None))[1])
        out[col + "_year"] = out.iso3.map(lambda k: b.get(k, (None, None))[0])
        print(f"{col}: {out[col].notna().sum()}/{len(out)} countries")
    out.to_csv(RAW / "worldbank_cache.csv", index=False)
    print("saved", RAW / "worldbank_cache.csv")


if __name__ == "__main__":
    main()
