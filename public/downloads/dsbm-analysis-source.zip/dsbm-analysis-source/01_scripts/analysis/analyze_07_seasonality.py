"""Seasonality of releases (V3.1). Needs 02_data/raw/dsbm_album_details.csv ; exits cleanly without it.

Why V3.1 differs from V3: the V3 test used ALL releases, which is biased by
  (a) the current year being incomplete (Jan-Oct only -> early months over-counted),
  (b) strong growth in releases per year (recent years dominate the pooled counts),
  (c) month coverage that rises from ~71% (1992-2009) to ~99% (2020+).
So the PRIMARY month test uses complete years only (FIRST_YEAR..CURRENT_YEAR-1), with an expectation proportional to
days-in-month, plus a pooled within-year chi-square (each year compared with its own total, so growth cannot matter).
A weekday test (day-precision dates only) is added, with a sensitivity check without the 1st of the month
(day==1 is over-represented: partly "unknown day" placeholders).

Outputs: 04_results/seasonality_counts.csv, seasonality_coverage_by_period.csv, seasonality_summary.json,
         seasonality_weekday.csv, seasonality_month_tests.csv; 03_figures/15_seasonality.png, 16_weekday.png
"""
import calendar
import json
import sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

FIRST_YEAR = 2015                      # month coverage >= ~98% from here on
LAST_COMPLETE = CURRENT_YEAR - 1       # the running year is incomplete
MIN_N = 60

path = RAW / "dsbm_album_details.csv"
if not path.exists():
    print("dsbm_album_details.csv not found -> seasonality skipped. Provide the album-details table (see INPUT_SCHEMA.md).")
    (RESULTS / "seasonality_summary.json").write_text(json.dumps({"available": False}), encoding="utf-8")
    sys.exit(0)

d = pd.read_csv(path, dtype={"album_id": str})
d["period"] = d.year.apply(period_of)
cov = d.groupby("period").agg(albums=("album_id", "count"), with_month=("month", lambda s: int(s.notna().sum()))).reindex([p[0] for p in PERIODS])
cov["month_known_pct"] = (cov.with_month / cov.albums * 100).round(1)
cov.to_csv(RESULTS / "seasonality_coverage_by_period.csv")

names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
m = d.dropna(subset=["month"]).copy(); m["month"] = m.month.astype(int); m["year"] = m.year.astype(int)
# dates later than today are announced releases, not yet happened - keep out of every test
today = pd.Timestamp.today().normalize()
m["is_future"] = pd.to_datetime(dict(year=m.year, month=m.month, day=m.day.fillna(1).astype(int)), errors="coerce") > today
n_future = int(m.is_future.sum())
m = m[~m.is_future]

def month_counts(x):
    return x.month.value_counts().reindex(range(1, 13), fill_value=0)

def month_test(x, label, years=None):
    c = month_counts(x); n = int(c.sum())
    if n < MIN_N:
        return {"subset": label, "n": n, "note": "too few"}
    ydays = [calendar.monthrange(2001, k)[1] + (0.25 if k == 2 else 0) for k in range(1, 13)]   # 28.25 for February
    exp = np.array(ydays) / sum(ydays) * n
    chi2, p = stats.chisquare(c.values, exp)
    winter = int(c[[12, 1, 2]].sum()); wexp = (31 + 31 + 28.25) / sum(ydays)
    return {"subset": label, "n": n, "chi2": round(float(chi2), 2), "p": round(float(p), 5),
            "peak": names[int(np.argmax(c.values / exp))], "low": names[int(np.argmin(c.values / exp))],
            "max_min_ratio": round(float((c.values / exp).max() / (c.values / exp).min()), 2),
            "winter_share_pct": round(winter / n * 100, 1), "winter_expected_pct": round(wexp * 100, 1),
            "winter_binomial_p": round(float(stats.binomtest(winter, n, wexp).pvalue), 5)}

complete = m[(m.year >= FIRST_YEAR) & (m.year <= LAST_COMPLETE)]
recent = m[(m.year >= 2020) & (m.year <= LAST_COMPLETE)]
tests = [month_test(m, "all releases (V3 method; biased)"),
         month_test(m[m.year <= LAST_COMPLETE], f"without {CURRENT_YEAR} (incomplete year)"),
         month_test(complete, f"complete years {FIRST_YEAR}-{LAST_COMPLETE}  [PRIMARY]"),
         month_test(recent, f"complete years 2020-{LAST_COMPLETE}")]
for t in ("Full-length", "EP", "Single", "Demo"):
    tests.append(month_test(complete[complete.page_type == t], f"{t}, complete years {FIRST_YEAR}-{LAST_COMPLETE}"))
pd.DataFrame(tests).to_csv(RESULTS / "seasonality_month_tests.csv", index=False)

# pooled within-year chi-square: every year vs its own total -> immune to growth between years
tot = 0.0; dof = 0
for y, g in complete.groupby("year"):
    c = month_counts(g).values
    if c.sum() >= MIN_N:
        ydays = np.array([31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]); e = ydays / ydays.sum() * c.sum()
        tot += float(stats.chisquare(c, e)[0]); dof += 11
pooled = {"chi2": round(tot, 1), "dof": dof, "p": round(float(stats.chi2.sf(tot, dof)), 5)} if dof else None

# per-month table (primary subset) + share of years in which the month is above its expected share
cm = month_counts(complete)
pd.DataFrame({"month": names, "releases_all": month_counts(m).values, f"releases_complete_{FIRST_YEAR}_{LAST_COMPLETE}": cm.values}) \
    .to_csv(RESULTS / "seasonality_counts.csv", index=False)

# ── weekday (needs the exact day) ──
wd_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
f = d[d.date_precision == "day"].copy()
f["dt"] = pd.to_datetime(dict(year=f.year, month=f.month.astype(int), day=f.day.astype(int)), errors="coerce")
f = f.dropna(subset=["dt"]); f = f[f.dt <= today]; f["wd"] = f.dt.dt.dayofweek
first_share = float((f.day == 1).mean() * 100)

def weekday_block(x, label):
    c = x.wd.value_counts().reindex(range(7), fill_value=0); n = int(c.sum())
    if n < MIN_N:
        return {"subset": label, "n": n, "note": "too few"}
    fri = int(c[4]); bt = stats.binomtest(fri, n, 1 / 7)
    ci = bt.proportion_ci(method="wilson")
    row = {"subset": label, "n": n, "friday_share_pct": round(fri / n * 100, 1),
           "friday_ci95": [round(ci.low * 100, 1), round(ci.high * 100, 1)], "friday_binomial_p": float(f"{bt.pvalue:.3g}"),
           "chi2_uniform_p": float(f"{stats.chisquare(c.values)[1]:.3g}")}
    row.update({k: int(c[i]) for i, k in enumerate(wd_names)})
    return row

fc = f[(f.year >= FIRST_YEAR) & (f.year <= LAST_COMPLETE)]
wk = [weekday_block(f, "all exact dates"),
      weekday_block(f[f.day != 1], "all exact dates, without the 1st of the month"),
      weekday_block(fc, f"complete years {FIRST_YEAR}-{LAST_COMPLETE}  [PRIMARY]"),
      weekday_block(fc[fc.day != 1], f"complete years {FIRST_YEAR}-{LAST_COMPLETE}, without the 1st")]
for p_name in [p[0] for p in PERIODS]:
    wk.append(weekday_block(f[f.period == p_name], f"period {p_name}"))
for t in ("Full-length", "EP", "Single", "Demo", "Split"):
    wk.append(weekday_block(f[f.page_type == t], f"type {t} (all years)"))
wkdf = pd.DataFrame(wk)
wkdf["friday_ci95"] = wkdf["friday_ci95"].apply(lambda v: "" if not isinstance(v, list) else f"{v[0]}-{v[1]}")
wkdf.to_csv(RESULTS / "seasonality_weekday.csv", index=False)

n_all = int(len(d)); n_m = int(len(m)) + n_future
summ = {"available": True, "albums": n_all, "month_known": n_m, "month_known_pct": round(n_m / max(n_all, 1) * 100, 1),
        "day_known": int((d.date_precision == "day").sum()), "future_dated_excluded": n_future,
        "complete_years": [FIRST_YEAR, LAST_COMPLETE], "month_tests": tests, "pooled_within_year_chi2": pooled,
        "weekday_primary": wk[2], "weekday_without_1st": wk[3], "day1_share_pct": round(first_share, 1),
        "day1_expected_pct": round(100 / 30.4, 1)}
p_main = next((t.get("p") for t in tests if "[PRIMARY]" in t["subset"]), None)
p_rec = next((t.get("p") for t in tests if t["subset"].startswith("complete years 2020")), None)
w_p = next((t.get("winter_binomial_p") for t in tests if "[PRIMARY]" in t["subset"]), None)
if p_main is None:
    summ["interpretation"] = "month test not possible"
elif p_main > 0.05:
    summ["interpretation"] = "month effect: not significant on complete years"
elif p_rec is not None and p_rec > 0.05:
    summ["interpretation"] = ("month effect: weak and unstable (significant only in 2015-onward, gone in 2020-onward; "
                              "max/min ratio ~1.2; depends on the null used) - do not over-interpret")
else:
    summ["interpretation"] = "month effect: significant on complete years and on 2020-onward"
summ["winter_hypothesis"] = ("not supported" if (w_p is None or w_p > 0.05) else "supported") + f" (binomial p={w_p})"
(RESULTS / "seasonality_summary.json").write_text(json.dumps(summ, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(summ, indent=1, ensure_ascii=False)); print(cov.to_string())

# ── figures ──
fig, ax = plt.subplots(figsize=(10, 5.5))
ydays = np.array([31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]); ydays = ydays / ydays.sum()
ax.bar(names, cm.values, color="steelblue", label=f"releases, complete years {FIRST_YEAR}-{LAST_COMPLETE}")
ax.plot(names, ydays * cm.sum(), "k--", marker="o", ms=3, label="expected if uniform (by days in month)")
pt = tests[2]
ax.set(title=f"DSBM releases by month, complete years only (n={int(cm.sum())}; chi-square p={pt.get('p')})", ylabel="Releases")
ax.legend(); ax.grid(axis="y", alpha=.3); plt.tight_layout(); plt.savefig(FIGS / "15_seasonality.png", dpi=150); plt.close()

fig, ax = plt.subplots(figsize=(10, 5.5))
wc = fc.wd.value_counts().reindex(range(7), fill_value=0)
ax.bar(wd_names, wc.values, color=["#9aa5b1"] * 4 + ["#d1495b"] + ["#9aa5b1"] * 2)
ax.axhline(wc.sum() / 7, color="k", ls="--", label="uniform expectation")
ax.set(title=f"DSBM releases by weekday (exact dates, {FIRST_YEAR}-{LAST_COMPLETE}, n={int(wc.sum())}; Friday {wk[2].get('friday_share_pct')}% vs 14.3%)",
       ylabel="Releases"); ax.legend(); ax.grid(axis="y", alpha=.3)
plt.tight_layout(); plt.savefig(FIGS / "16_weekday.png", dpi=150); plt.close()
