"""Offline merge: bands (dsbm_clean) + temperature + World Bank cache -> regression_dataset.csv

Key fixes vs. the first version:
  * band_count = ALL bands of a country (the old code dropped bands without formed_year,
    ~27% overall, ~35% for the USA) - the legacy count is kept as band_count_with_year.
  * names are canonicalised (Türkiye->Turkey, Korea, South->South Korea ...), populations added.
  * temperature overrides + quality flags (temp_flags.csv) are honoured.
"""
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

bands = pd.read_csv(PROC / "dsbm_clean.csv")
bands = bands[~bands.country_clean.isin(NON_COUNTRIES)]

g = bands.groupby("country_clean").agg(
    band_count=("ma_id", "count"),
    band_count_with_year=("formed_year", "count"),
    population_m=("population_m", "first"),
).reset_index()
g["bands_per_million"] = g.band_count / g.population_m
g["bands_per_million_legacy"] = g.band_count_with_year / g.population_m

clim = pd.read_csv(RAW / "climate_country.csv")
clim["country_clean"] = clim.country_clean.map(canon_country)
clim = clim.drop_duplicates("country_clean")
ov = pd.read_csv(RAW / "temp_overrides.csv")
if len(ov):
    clim = clim.merge(ov, on="country_clean", how="outer", suffixes=("", "_ov"))
    m = clim["avg_temp_c_ov"].notna()
    clim.loc[m, "avg_temp_c"] = clim.loc[m, "avg_temp_c_ov"]
    clim.loc[m, "temp_source"] = clim.loc[m, "source"]
g = g.merge(clim[["country_clean", "iso3", "avg_temp_c", "temp_source"]], on="country_clean", how="left")
g["iso3"] = g.iso3.fillna(g.country_clean.map(ISO3_MANUAL))

flags = pd.read_csv(RAW / "temp_flags.csv")
g = g.merge(flags[["country_clean", "flag"]].rename(columns={"flag": "temp_flag"}), on="country_clean", how="left")

wb = pd.read_csv(RAW / "worldbank_cache.csv").drop_duplicates("iso3")
g = g.merge(wb, on="iso3", how="left")

g.sort_values("band_count", ascending=False).to_csv(PROC / "regression_dataset.csv", index=False)
print(f"{len(g)} countries with bands & population")
print("  with temperature:", g.avg_temp_c.notna().sum(),
      "| temp+GDP+internet:", g.dropna(subset=["avg_temp_c", "gdp_per_capita", "internet_pct"]).shape[0])
print("  no temperature :", g[g.avg_temp_c.isna()][["country_clean", "band_count"]].values.tolist())
print("  flagged        :", g[g.temp_flag.notna()][["country_clean", "temp_flag"]].values.tolist())
