"""Descriptive analysis.  Input: 02_data/raw/dsbm_enriched.csv
Outputs: 02_data/processed/dsbm_clean.csv, figures 01-05, 04_results/descriptive_summary.json
"""
import json
import sys
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

df = pd.read_csv(RAW / "dsbm_enriched.csv", encoding="utf-8")
summary = {"n_bands": int(len(df))}
print(f"Loaded {len(df)} rows")

# ── cleaning ───────────────────────────────────────────────────────────
df["formed_year"] = pd.to_numeric(df["formed_in"].astype(str).str.extract(r"(\d{4})")[0], errors="coerce")
df["status_clean"] = df["status"].astype(str).str.strip().str.lower().replace("nan", np.nan)
df["country_clean"] = df["country_detail"].fillna(df["country"]).astype(str).str.strip().map(canon_country)
df["themes_list"] = df["themes"].apply(split_list)
df["is_pure_dsbm"] = df["genres_detail"].apply(is_pure_dsbm)
df["population_m"] = df["country_clean"].map(POPULATION_M)
df["age"] = CURRENT_YEAR - df["formed_year"]

# a missing status means the profile record is absent -> track it so it isn't mistaken for "no data"
df["profile_present"] = df["status"].notna()
if "label_type" not in df.columns:
    df["label_type"] = np.nan
summary["profiles_missing"] = int((~df["profile_present"]).sum())
summary["formed_year_missing"] = int(df["formed_year"].isna().sum())
summary["formed_year_missing_pct"] = round(df["formed_year"].isna().mean() * 100, 1)
n_theme = int(df["themes"].notna().sum())
summary["themes_available"] = n_theme
summary["themes_missing_pct"] = round((1 - n_theme / len(df)) * 100, 1)
summary["non_country_rows"] = {k: int((df.country_clean == k).sum()) for k in ("International", "Unknown")}
summary["rows_without_population"] = int(df["population_m"].isna().sum())
print("profiles missing:", summary["profiles_missing"],
      "| no population:", summary["rows_without_population"])

# ── 2. formation by year (current year is partial -> shown hatched) ───
yearly = df["formed_year"].dropna().astype(int).value_counts().sort_index()
yearly = yearly[(yearly.index >= 1985) & (yearly.index <= CURRENT_YEAR)]
full = yearly[yearly.index < CURRENT_YEAR]
fig, ax = plt.subplots(figsize=(12, 5))
ax.bar(full.index, full.values, color="steelblue", edgecolor="black", linewidth=0.3)
if CURRENT_YEAR in yearly.index:
    ax.bar([CURRENT_YEAR], [yearly[CURRENT_YEAR]], color="lightgrey", edgecolor="black", hatch="//",
           linewidth=0.3, label=f"{CURRENT_YEAR} (partial year)")
    ax.legend()
ax.set(title="DSBM band formation by year", xlabel="Year formed", ylabel="Number of bands")
ax.grid(axis="y", alpha=.3); plt.tight_layout(); plt.savefig(FIGS / "01_bands_by_year.png", dpi=150); plt.close()
cum = full.cumsum()
fig, ax = plt.subplots(figsize=(12, 5))
ax.plot(cum.index, cum.values, marker="o", color="darkred")
ax.set(title="Cumulative DSBM band formations", xlabel="Year", ylabel="Cumulative bands")
ax.grid(alpha=.3); plt.tight_layout(); plt.savefig(FIGS / "02_cumulative.png", dpi=150); plt.close()
top3 = full.sort_values(ascending=False).head(3)
summary["peak_years"] = {int(k): int(v) for k, v in top3.items()}
summary["first_year"] = int(full.index.min())
summary["partial_year"] = {int(CURRENT_YEAR): int(yearly.get(CURRENT_YEAR, 0))}
print("peak years:", summary["peak_years"])

# ── 3. countries, raw ─────────────────────────────────────────────────
real = df[~df.country_clean.isin(NON_COUNTRIES)]
top = real["country_clean"].value_counts().head(20)
summary["top_countries_raw"] = {k: int(v) for k, v in top.head(10).items()}
fig, ax = plt.subplots(figsize=(10, 7))
top[::-1].plot(kind="barh", ax=ax, color="teal"); ax.set(title="Top 20 countries by DSBM band count (raw)", xlabel="Number of bands")
plt.tight_layout(); plt.savefig(FIGS / "03_top_countries_raw.png", dpi=150); plt.close()

# ── 4. per capita: ALL bands of a country; min 5 bands to rank ────────
cnt = real.groupby("country_clean").agg(n=("ma_id", "count"), pop=("population_m", "first")).dropna()
cnt["per_million"] = cnt["n"] / cnt["pop"]
MIN_BANDS = 5
pc = cnt[cnt["n"] >= MIN_BANDS].sort_values("per_million", ascending=False).head(20)
summary["per_capita_min_bands"] = MIN_BANDS
summary["per_capita_top"] = {k: {"bands": int(r.n), "per_million": round(r.per_million, 2)} for k, r in pc.head(10).iterrows()}
summary["per_capita_small_n_note"] = {k: {"bands": int(r.n), "per_million": round(r.per_million, 2)}
                                       for k, r in cnt[cnt.n < MIN_BANDS].sort_values("per_million", ascending=False).head(5).iterrows()}
fig, ax = plt.subplots(figsize=(10, 7))
pc["per_million"][::-1].plot(kind="barh", ax=ax, color="darkred")
ax.set_yticklabels([f"{c} (n={int(cnt.loc[c, 'n'])})" for c in pc.index[::-1]])
ax.set(title=f"Top 20 countries: DSBM bands per million (min {MIN_BANDS} bands)", xlabel="Bands per million")
plt.tight_layout(); plt.savefig(FIGS / "04_per_capita.png", dpi=150); plt.close()

# ── 5. themes (denominator = bands that HAVE themes) ──────────────────
tc = Counter(t for lst in df.themes_list for t in lst)
summary["top_themes"] = dict(tc.most_common(15))
if not tc:
    print("WARNING: no themes in the dataset (check the input table). Skipping theme plot.")
else:
    fig, ax = plt.subplots(figsize=(10, 8))
    pd.Series(dict(tc.most_common(25)))[::-1].plot(kind="barh", ax=ax, color="purple")
    ax.set(title="Top 25 lyrical themes in DSBM", xlabel="Number of bands (of those with themes listed)")
    plt.tight_layout(); plt.savefig(FIGS / "05_themes.png", dpi=150); plt.close()

CLIMATE_KEYS = ("winter", "cold", "frost", "ice", "snow", "freez")   # explicitly climate
NATURE_KEYS = ("nature", "forest", "mountain", "landscape", "wilderness")
WARM_KEYS = ("summer", "sun", "heat", "warm", "desert", "tropic")
def has(lst, keys): return any(any(k in t for k in keys) for t in lst)
has_t = df[df.themes.notna()]
if len(has_t) == 0:
    has_t = df.iloc[0:0]
for label, keys in (("climate_explicit", CLIMATE_KEYS), ("nature", NATURE_KEYS), ("warm", WARM_KEYS)):
    k = int(has_t.themes_list.apply(lambda l: has(l, keys)).sum())
    summary[f"themes_{label}"] = {"bands": k, "pct_of_bands_with_themes": round(k / max(len(has_t), 1) * 100, 1)}
psych = ("depress", "suicid", "death", "sad", "despair", "loneli", "misanthrop", "self-harm", "mental")
summary["themes_psychological"] = {"pct_of_bands_with_themes": round(float(has_t.themes_list.apply(lambda l: has(l, psych)).mean() * 100), 1) if len(has_t) else None}
print({k: v for k, v in summary.items() if k.startswith("themes_")})

# ── 6. genre purity ───────────────────────────────────────────────────
summary["pure_dsbm"] = {"bands": int(df.is_pure_dsbm.sum()), "pct": round(df.is_pure_dsbm.mean() * 100, 1)}
comp = Counter(g for s in df.genres_detail for g in split_genres(s) if g not in {"depressive black metal", "depressive"})
summary["companion_genres"] = dict(comp.most_common(10))

# ── 7. labels: "current label" (active bands) and "last label" (inactive) are different things ──
is_unsig = df.current_label.eq("Unsigned/independent")
cur, last = df.label_type.eq("current"), df.label_type.eq("last")
summary["unsigned"] = {
    "among_current_label_active_bands": {"unsigned": int((is_unsig & cur).sum()), "bands": int(cur.sum()),
                                         "pct": round((is_unsig & cur).sum() / max(cur.sum(), 1) * 100, 1)},
    "among_last_label_inactive_bands": {"unsigned": int((is_unsig & last).sum()), "bands": int(last.sum()),
                                        "pct": round((is_unsig & last).sum() / max(last.sum(), 1) * 100, 1)},
    "all_profiles": {"unsigned": int(is_unsig.sum()), "bands": int(df.profile_present.sum()),
                          "pct": round(is_unsig.sum() / max(df.profile_present.sum(), 1) * 100, 1)},
    "empty_label_cells": int(df.current_label.isna().sum()),
}
summary["top_labels"] = {k: int(v) for k, v in df.loc[~is_unsig, "current_label"].value_counts().head(10).items()}

# ── 8. status / age ───────────────────────────────────────────────────
vc = df.status_clean.value_counts()
summary["status_pct_of_all"] = {k: round(v / len(df) * 100, 1) for k, v in vc.items()}
active = df.status_clean.eq("active")
summary["median_age_all"] = float(df.age.median())
summary["median_age_active"] = float(df.loc[active, "age"].median())
summary["age_reference_year"] = CURRENT_YEAR

# ── 10. save ──────────────────────────────────────────────────────────
cols = ["ma_id", "name", "country_clean", "formed_year", "status_clean", "genres_detail",
        "themes", "current_label", "label_type", "is_pure_dsbm", "population_m", "age", "profile_present"]
df[cols].to_csv(PROC / "dsbm_clean.csv", index=False, encoding="utf-8")
(RESULTS / "descriptive_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(summary, indent=1, ensure_ascii=False))
