"""Small dependency-free (numpy + scipy) OLS / Poisson implementations.
Verified against the original statsmodels output (coefficients and p-values)."""
import numpy as np
from scipy import stats


def ols(X, y, names, robust="HC3"):
    """OLS with intercept. Returns dict with coef, classical p, robust p, R2."""
    X = np.column_stack([np.ones(len(y)), np.asarray(X, float)])
    y = np.asarray(y, float)
    n, k = X.shape
    xtx_inv = np.linalg.inv(X.T @ X)
    b = xtx_inv @ X.T @ y
    res = y - X @ b
    s2 = res @ res / (n - k)
    se = np.sqrt(np.diag(s2 * xtx_inv))
    h = np.einsum("ij,jk,ik->i", X, xtx_inv, X)
    Xr = X * (res / (1 - h))[:, None]                      # HC3
    se_r = np.sqrt(np.diag(xtx_inv @ (Xr.T @ Xr) @ xtx_inv))
    tcrit = stats.t.ppf(0.975, n - k)
    r2 = 1 - res @ res / ((y - y.mean()) @ (y - y.mean()))
    nm = ["const"] + list(names)
    return {
        "n": n, "r2": r2, "adj_r2": 1 - (1 - r2) * (n - 1) / (n - k),
        "coef": dict(zip(nm, b)),
        "se": dict(zip(nm, se)),
        "p": dict(zip(nm, 2 * stats.t.sf(abs(b / se), n - k))),
        "p_robust": dict(zip(nm, 2 * stats.t.sf(abs(b / se_r), n - k))),
        "ci_robust": dict(zip(nm, zip(b - tcrit * se_r, b + tcrit * se_r))),
    }


def poisson(X, y, offset, names, max_iter=200):
    """Poisson GLM (log link, offset) with sandwich (robust) standard errors.
    Robust SEs make it valid under over-dispersion (quasi-Poisson)."""
    X = np.column_stack([np.ones(len(y)), np.asarray(X, float)])
    y = np.asarray(y, float)
    off = np.asarray(offset, float)
    b = np.zeros(X.shape[1])
    b[0] = np.log(y.mean() / np.exp(off).mean())
    for _ in range(max_iter):
        mu = np.exp(X @ b + off)
        z = X @ b + (y - mu) / mu
        bn = np.linalg.solve(X.T @ (X * mu[:, None]), X.T @ (mu * z))
        done = np.abs(bn - b).max() < 1e-10
        b = bn
        if done:
            break
    mu = np.exp(X @ b + off)
    A = np.linalg.inv(X.T @ (X * mu[:, None]))
    B = X.T @ (X * ((y - mu) ** 2)[:, None])
    se = np.sqrt(np.diag(A @ B @ A))
    nm = ["const"] + list(names)
    return {
        "n": len(y), "dispersion": ((y - mu) ** 2 / mu).sum() / (len(y) - X.shape[1]),
        "coef": dict(zip(nm, b)), "se": dict(zip(nm, se)),
        "p_robust": dict(zip(nm, 2 * stats.norm.sf(abs(b / se)))),
        "ci_robust": dict(zip(nm, zip(b - 1.96 * se, b + 1.96 * se))),
    }


def kaplan_meier(durations, events):
    """Kaplan-Meier survival curve. events: 1 = event observed, 0 = censored.
    Returns DataFrame-like dict of arrays: t, at_risk, deaths, surv, plus median (None if never < 0.5)."""
    d = np.asarray(durations, float); e = np.asarray(events, int)
    times = np.unique(d[e == 1])
    surv, s, at_risk, deaths = [], 1.0, [], []
    for t in times:
        n = int((d >= t).sum()); k = int(((d == t) & (e == 1)).sum())
        s *= 1 - k / n; surv.append(s); at_risk.append(n); deaths.append(k)
    surv = np.array(surv)
    med = next((float(t) for t, sv in zip(times, surv) if sv <= 0.5), None)
    return {"t": times, "surv": surv, "at_risk": np.array(at_risk), "deaths": np.array(deaths), "median": med}


def survival_at(km, t):
    """S(t) from a km dict (1.0 before the first event)."""
    idx = np.searchsorted(km["t"], t, side="right") - 1
    return 1.0 if idx < 0 else float(km["surv"][idx])


def logrank(d1, e1, d2, e2):
    """Two-group log-rank test. Returns (chi2, p)."""
    d = np.concatenate([d1, d2]).astype(float); e = np.concatenate([e1, e2]).astype(int)
    g = np.concatenate([np.zeros(len(d1)), np.ones(len(d2))])
    o1 = ex1 = var = 0.0
    for t in np.unique(d[e == 1]):
        at = d >= t; n = at.sum(); n1 = (at & (g == 0)).sum()
        k = ((d == t) & (e == 1)).sum()
        o1 += ((d == t) & (e == 1) & (g == 0)).sum()
        ex1 += k * n1 / n
        if n > 1:
            var += k * (n1 / n) * (1 - n1 / n) * (n - k) / (n - 1)
    chi2 = (o1 - ex1) ** 2 / var if var > 0 else float("nan")
    return chi2, float(stats.chi2.sf(chi2, 1)) if var > 0 else float("nan")
