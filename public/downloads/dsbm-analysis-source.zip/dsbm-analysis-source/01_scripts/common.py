"""Shared paths, country-name handling, genre parsing and small helpers.

Every script does:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from common import *
so it can be run from any working directory.
"""
import os
import re
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "02_data" / "raw"
PROC = ROOT / "02_data" / "processed"
FIGS = ROOT / "03_figures"
RESULTS = ROOT / "04_results"
for _d in (RAW, PROC, FIGS, RESULTS):
    _d.mkdir(parents=True, exist_ok=True)

CURRENT_YEAR = date.today().year

# ── public data download (Berkeley Earth file, World Bank API) ───────────────────────
def fetch_text(url, timeout=60):
    import urllib.request
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def fetch_json(url, timeout=60):
    import json
    return json.loads(fetch_text(url, timeout))


# ── countries ──────────────────────────────────────────────────────────
# Names used by Metal Archives -> one canonical name used everywhere
CANON = {"Türkiye": "Turkey", "Korea, South": "South Korea"}
NON_COUNTRIES = {"International", "Unknown", "N/A", "None", ""}

# manual ISO3 for names that country_converter / lookups often miss
ISO3_MANUAL = {"Turkey": "TUR", "Czechia": "CZE", "South Korea": "KOR",
               "North Macedonia": "MKD"}

# canonical name -> name in Berkeley Earth "GlobalLandTemperaturesByCountry"
# ("X (Europe)" variants are tried first automatically: they exclude overseas
#  territories such as Greenland for Denmark.)
BERKELEY_ALIAS = {"Czechia": "Czech Republic", "North Macedonia": "Macedonia",
                  "Myanmar": "Burma"}


def canon_country(name):
    if name is None:
        return None
    n = str(name).strip()
    return CANON.get(n, n)


# Population, millions (World Bank, ~2023; rounded). Verify before publishing.
POPULATION_M = {
    "United States": 334.9, "Norway": 5.5, "Sweden": 10.5, "Finland": 5.5,
    "Denmark": 5.9, "Germany": 84.4, "France": 68.0, "United Kingdom": 67.7,
    "Canada": 40.0, "Australia": 26.5, "Brazil": 216.4, "Poland": 36.8,
    "Netherlands": 17.9, "Italy": 58.9, "Spain": 48.4, "Russia": 144.4,
    "Ukraine": 37.7, "Japan": 124.5, "Mexico": 128.5, "Argentina": 46.6,
    "Chile": 19.6, "Colombia": 52.1, "Portugal": 10.5, "Belgium": 11.7,
    "Switzerland": 8.8, "Austria": 9.1, "Czechia": 10.9, "Slovakia": 5.4,
    "Hungary": 9.6, "Romania": 19.0, "Greece": 10.4, "Turkey": 85.3,
    "Israel": 9.8, "South Korea": 51.7, "India": 1428.6, "China": 1425.7,
    "Indonesia": 277.5, "Philippines": 117.3, "Thailand": 71.8,
    "Malaysia": 34.3, "Singapore": 5.9, "New Zealand": 5.2,
    "South Africa": 60.4, "Egypt": 112.7, "Iran": 89.2, "Iraq": 45.5,
    "Saudi Arabia": 36.9, "United Arab Emirates": 9.5, "Ireland": 5.3,
    "Iceland": 0.39, "Luxembourg": 0.66, "Estonia": 1.4, "Latvia": 1.9,
    "Lithuania": 2.9, "Croatia": 3.9, "Serbia": 6.7, "Bulgaria": 6.5,
    "Belarus": 9.2, "Kazakhstan": 20.0, "Georgia": 3.7, "Armenia": 2.8,
    "Azerbaijan": 10.1, "Mongolia": 3.5, "Peru": 34.4, "Ecuador": 18.2,
    "Venezuela": 28.8, "Uruguay": 3.4, "Paraguay": 6.9, "Bolivia": 12.4,
    "Costa Rica": 5.2, "Guatemala": 17.6, "Cuba": 11.2, "Puerto Rico": 3.2,
    "Panama": 4.5,
    # added (these were silently dropped in the first version)
    "Moldova": 2.6, "Morocco": 37.8, "Vietnam": 98.9, "Sri Lanka": 21.9,
    "Tunisia": 12.4, "Jordan": 11.3, "Bangladesh": 172.9, "Honduras": 10.6,
    "Nicaragua": 6.9, "Bosnia and Herzegovina": 3.2, "Slovenia": 2.1,
    "El Salvador": 6.3, "Lebanon": 5.4, "Syria": 23.2, "Algeria": 45.6,
    "Angola": 36.7, "Uzbekistan": 36.4, "North Macedonia": 1.8,
    "Taiwan": 23.4, "Tajikistan": 9.9, "Hong Kong": 7.5, "Gibraltar": 0.034,
}


# ── genres ─────────────────────────────────────────────────────────────
def split_genres(s):
    """'Depressive Black Metal (early); Black Metal (later)' ->
       ['depressive black metal', 'black metal']  (qualifiers removed)."""
    if s is None or (isinstance(s, float) and s != s):
        return []
    s = re.sub(r"\([^)]*\)", "", str(s).lower())
    return [p.strip() for p in re.split(r"[;/,]", s) if p.strip()]


_DSBM_TOKENS = {"depressive black metal", "depressive suicidal black metal",
                "dsbm", "depressive", "depressive black"}


def is_pure_dsbm(genres_str):
    """True only if every genre token is plain DSBM.
    ('Depressive/Post-Black Metal', 'Raw Depressive Black Metal' etc. are hybrids)."""
    toks = split_genres(genres_str)
    return bool(toks) and all(t in _DSBM_TOKENS for t in toks)


def split_list(s):
    if s is None or (isinstance(s, float) and s != s):
        return []
    return [p.strip() for p in re.split(r"[,/;]", str(s).lower()) if p.strip()]


# ── genre families (network / counts) ─────────────────────────────────
_FAMILY = {
    "atmospheric": "atmospheric black metal", "atmospheric black metal": "atmospheric black metal",
    "raw": "raw black metal", "raw black metal": "raw black metal",
    "post-black metal": "post-black metal", "post black metal": "post-black metal",
    "ambient": "ambient", "dark ambient": "dark ambient",
    "doom metal": "doom metal", "funeral doom metal": "doom metal", "funeral doom": "doom metal",
    "shoegaze": "shoegaze", "rock": "rock", "post-rock": "post-rock", "post-punk": "post-punk",
    "experimental": "experimental", "experimental black metal": "experimental",
}


def genre_families(genres_str):
    """Companion genre families of a band, with every DSBM spelling removed
    ('depressive', 'depressive black', '(early)', '(later)' ... are NOT separate genres)."""
    out = []
    for t in split_genres(genres_str):
        if t in _DSBM_TOKENS or "depressive" in t:
            continue
        t = _FAMILY.get(t, t)
        if t not in out:
            out.append(t)
    return out


def parse_years_active(s):
    """'1992-2000 (as X), 2005-present' -> (first_year, last_year_or_None_if_present). (None, None) if unparseable."""
    if s is None or (isinstance(s, float) and s != s):
        return None, None
    txt = str(s).lower()
    spans = re.findall(r"(\d{4})\s*[-–]\s*(\d{4}|present|\?)", txt)
    singles = re.findall(r"\b(\d{4})\b", re.sub(r"\d{4}\s*[-–]\s*(\d{4}|present|\?)", "", txt))
    starts = [int(a) for a, _ in spans] + [int(x) for x in singles]
    if not starts:
        return None, None
    ends = [None if b in ("present", "?") else int(b) for _, b in spans]
    first = min(starts)
    if any(e is None for e in ends) and spans:
        return first, None
    last = max([e for e in ends if e is not None] + [int(x) for x in singles] + [first])
    return first, last


def wilson(k, n, z=1.96):
    """Wilson score interval for a proportion (returns (low, high) in 0..1)."""
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * ((p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5) / d
    return (max(0.0, c - h), min(1.0, c + h))


# fixed periods used by every time-trend analysis (decades are too thin before 2010)
PERIODS = [("1992-2009", 1900, 2009), ("2010-2014", 2010, 2014), ("2015-2019", 2015, 2019), ("2020-now", 2020, 3000)]


def period_of(year):
    if year is None or year != year:
        return None
    for name, lo, hi in PERIODS:
        if lo <= year <= hi:
            return name
    return None
