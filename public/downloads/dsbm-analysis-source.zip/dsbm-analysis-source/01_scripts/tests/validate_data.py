"""Data integrity checks.  python3 01_scripts/tests/validate_data.py
Exit code 1 only for hard errors (inconsistent files); quality problems are WARNINGS (listed, never silent).
Writes 04_results/data_validation.json."""
import json
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import *  # noqa

errors, warnings, info = [], [], {}
def err(m): errors.append(m)
def warn(m): warnings.append(m)

enr = pd.read_csv(RAW / "dsbm_enriched.csv"); n = len(enr)
info["bands"] = n
if enr.ma_id.duplicated().any(): err("duplicate ma_id in dsbm_enriched.csv")
if (enr.parse_version.astype(str) != "2").any(): warn(f"{int((enr.parse_version.astype(str) != '2').sum())} rows not parsed by parser v2")
if enr.status.isna().any(): warn(f"{int(enr.status.isna().sum())} bands have no status (profile record missing) ")
if enr.current_label.isna().any(): warn(f"{int(enr.current_label.isna().sum())} bands without label cell")
info["themes_missing"] = int(enr.themes.isna().sum())
if info["themes_missing"] > 0.4 * n: warn("more than 40% of bands have no themes - check the input table")

clean = pd.read_csv(PROC / "dsbm_clean.csv")
if len(clean) != n or set(clean.ma_id) != set(enr.ma_id): err("dsbm_clean.csv does not match dsbm_enriched.csv - re-run analyze_01_descriptive.py")

disc = pd.read_csv(RAW / "dsbm_discography.csv", dtype={"album_id": str})
need = {"ma_id", "album", "type", "year_raw", "year", "month"}
if not need <= set(disc.columns): err(f"discography columns missing: {need - set(disc.columns)}")
real = disc[disc.album != "NO_RELEASES"]
info["discography"] = {"rows": len(disc), "releases": len(real), "bands": int(disc.ma_id.nunique())}
if not set(disc.ma_id.astype(str)) <= set(enr.ma_id.astype(str)): err("discography has bands that are not in dsbm_enriched.csv")
missing = n - disc.ma_id.nunique()
if missing: warn(f"{missing} bands have no discography row yet ")
dups = int(disc.duplicated().sum())
if dups: warn(f"{dups} exact duplicate discography rows (the analysis removes them)")
share = disc[disc.album == "NO_RELEASES"].ma_id.nunique() / max(disc.ma_id.nunique(), 1) * 100
info["no_releases_share_pct"] = round(share, 1)
if share > 5: warn(f"{share:.1f}% of bands recorded as NO_RELEASES (expected a few %). The discography table looks incomplete.")
if "album_id" not in disc.columns or (real.get("album_id", pd.Series(dtype=str)).fillna("") == "").mean() > 0.005:
    warn("album_id/album_url missing for some releases ")
yr = real.year.dropna()
if len(yr) and (yr.min() < 1985 or yr.max() > CURRENT_YEAR): err(f"release years out of range: {yr.min()}..{yr.max()}")
f = enr.assign(fy=pd.to_numeric(enr.formed_in.astype(str).str.extract(r"(\d{4})")[0], errors="coerce"))[["ma_id", "fy"]]
x = real.merge(f, on="ma_id"); x = x[x.fy.notna()]
early = int((x.year < x.fy - 1).sum())
info["releases_before_formation_gt1y"] = early
if len(x) and early / len(x) > 0.02: warn(f"{early} releases are dated >1 year before the band's formation")

det = RAW / "dsbm_album_details.csv"
if det.exists():
    d = pd.read_csv(det, dtype={"album_id": str})
    if d.album_id.duplicated().any(): err("duplicate album_id in dsbm_album_details.csv")
    if "album_id" in disc.columns and not set(d.album_id) <= set(disc.album_id.dropna().astype(str)): err("album details contain ids not in the discography")
    info["album_details"] = {"albums": len(d), "precision": d.date_precision.value_counts(dropna=False).to_dict()}
else:
    info["album_details"] = "not fetched yet"

reg = pd.read_csv(PROC / "regression_dataset.csv")
if reg.avg_temp_c.dropna().between(-40, 35).all() is False: err("temperatures outside -40..35 C")
info["countries_in_regression_dataset"] = len(reg)

print(f"{n} bands | errors: {len(errors)} | warnings: {len(warnings)}")
for m in errors: print("  ERROR  ", m)
for m in warnings: print("  WARNING", m)
(RESULTS / "data_validation.json").write_text(json.dumps({"errors": errors, "warnings": warnings, "info": info}, indent=2, default=str), encoding="utf-8")
sys.exit(1 if errors else 0)
