#!/usr/bin/env bash
# Re-creates every table, figure and summary from the input tables listed in INPUT_SCHEMA.md.
# Usage: bash run_all.sh            (PYTHON=python bash run_all.sh  to force another interpreter)
set -euo pipefail
cd "$(dirname "$0")"
PY="${PYTHON:-$(command -v python3 || command -v python)}"
cd 01_scripts/analysis
"$PY" analyze_01_descriptive.py          # cleaning + descriptive tables  -> 02_data/processed/dsbm_clean.csv
"$PY" build_regression_dataset.py        # country-level table (bands + temperature + economy)
"$PY" ../tests/validate_data.py || { echo "validation ERRORS above - fix the inputs before trusting results"; exit 1; }
"$PY" analyze_02_climate_hypothesis.py   # simple temperature test
"$PY" analyze_03_multiple_regression.py  # controls + robustness grid + leave-one-out
"$PY" analyze_04_theme_trends.py         # themes by period
"$PY" analyze_05_advanced_analytics.py   # longevity (Kaplan-Meier), companion genres, thematic geography
"$PY" analyze_06_release_types.py        # release formats by period
"$PY" analyze_07_seasonality.py          # months and weekdays
"$PY" generate_summary.py
# Optional, only to rebuild the two external country-level inputs from public sources:
#   python build_climate_dataset.py [--csv GlobalLandTemperaturesByCountry.csv]   (Berkeley Earth)
#   python build_economic_dataset.py                                             (World Bank API)
